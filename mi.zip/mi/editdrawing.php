<?php 
include('config.php');
extract($_POST); 
if (!empty($_POST['update']))
{
session_start();
$status = mysql_real_escape_string($_POST['status']);
$title = mysql_real_escape_string($_POST['title']);
$description = mysql_real_escape_string($_POST['description']);
$ip_address = mysql_real_escape_string($_POST['ip_address']);
//$like_count = mysql_real_escape_string($_POST['like_count']);
$proof_file = mysql_real_escape_string($_POST['proof_file']);
$is_sponsored = mysql_real_escape_string($_POST['is_sponsored']);
$likes = mysql_real_escape_string($_POST['likes']);
$reports = mysql_real_escape_string($_POST['reports']);
$clicks = mysql_real_escape_string($_POST['clicks']);
$volunteer_id = mysql_real_escape_string($_POST['volunteer_id']);

 $username = mysql_real_escape_string($_POST['username']);
 $email = mysql_real_escape_string($_POST['email']);
//exit;
		//for image
$drawing_image=$_FILES['drawing_image']['name'];
$drawing_size=$_FILES['drawing_image']['size'];

 mysql_query("update mp_drawings set status='$status',reasonforblock='$reasonforblock',updated_at=now() where id='{$_GET['id']}'");


 // mysql_query("update mp_drawings set status='$status',reasonforblock='$reasonforblock',title='$title',description='$description',ip_address='$ip_address',drawing_image='$drawing_image',drawing_size='$drawing_size',proof_file='$proof_file',updated_at=now(),is_sponsored='$is_sponsored',likes='$likes',reports='$reports',clicks='$clicks',volunteer_id='$volunteer_id' where id='{$_GET['id']}'");
//save user's image
//move_uploaded_file($_FILES['drawing_image']['tmp_name'],"images/drawings/".$_FILES['drawing_image']['name']);
//exit; 

//echo $status;
 $email;

//exit;

if($status == '1')
 {
 // multiple recipients
$to  = 'mail-noreply@milliondollardrawings.com' . ', '; // note the comma
$to .= $email;

//echo $email;

// subject
$subject = 'Your Art Work Blocked';

// message
$message = '
<table border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="#00718a">
<tbody>
<tr>
<td style="padding-top: 40px; padding-left: 20px; padding-right: 20px;" align="center" valign="top">
<table border="0" width="640" cellspacing="0" cellpadding="0" align="center" bgcolor="#010101">
<tbody>
<tr>
<td>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding-bottom: 10px; padding-top: 15px; padding-left: 17px;" align="center" valign="middle" width="180">
<div align="center"><a target="_blank" data-saferedirecturl=""><img class="CToWUd" style="display: block;" src="http://sathiyasai.com/mi/img/million2.png" alt="" width="550" height="85" border="0" /></a></div>
</td>
<td valign="middle" width="520">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding-left: 5px; padding-right: 5px; padding-bottom: 5px;" align="right"><!--<span style="font-size: 18px; line-height: 18px; color: #ffffff; font-family: Arial, sans-serif;"><a style="text-decoration: none;" href="tel:040-49187600" target="_blank"><span style="color: #ffffff;">24/7 Support: <u></u>044-123456<u> </u></span></a></span>--></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table border="0" width="600" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="font-size: 26px; line-height: 40px; padding: 40px 40px 20px 40px;" align="left"><span style="font-size: 26px; line-height: 40px; color: #333333; font-family: Boing-Bold, "Arial Black", Arial, sans-serif;">Your artwork has been blocked</span></td>
</tr>
<tr>
<td align="center" valign="top">
<table border="0" width="100%" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="padding: 20px 40px 20px 40px;" align="left"><span style="font-size: 14px; line-height: 20px; color: #333333; font-family: Arial, sans-serif;"><span style="font-size: 14px; line-height: 20px; color: #333333; font-family: Arial, sans-serif;">Hi '.$username.' ,<br /> We regret to inform you that your artwork has been blocked due to afore-mentioned reasons:<br /></span></span>
<ul>
<li>Your image is blurred, or</li>
<li>You have uploaded a duplicate image, or</li>
<li>Your artwork has violated the copyright or</li>
<li>Hatred artwork or violence artwork or Erotic artwork</li>
<li>Your artwork is not complying with the terms and conditions of milliondollardrawings</li>
</ul>
<span style="font-size: 14px; line-height: 20px; color: #333333; font-family: Arial, sans-serif;"><br /> It is mandatorily to comply with all the terms and conditions of the Milliondollardrawings.<br /> It is a warning message to inform you that if we get the above-mentioned or similar problems from your account, it may lead to automated account deactivation.<br /> <br /> Take care.<br /> The MDD Team<br /> This is a system generated mail, please do not reply this. For further queries, you may contact us to support@milliondollardrawings.com<br /> If you dont want to receive these emails from Milliondollardrawings in the future, for unsubscribing please send an email to unsubscribe@milliondollardrawngs.com </span></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td align="center" valign="top">
<table border="0" width="600" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="padding: 20px;" align="left">&nbsp;</td>
</tr>
</tbody>
</table>
<table border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="#fedc45">
<tbody>
<tr>
<td align="center" valign="top">
<table border="0" width="640" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding: 20px 40px 20px 40px;">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding: 0px 0px 5px 0px;" align="left" valign="middle"><span style="font-size: 20px; line-height: 22px; color: #333333; font-family: Arial, sans-serif;"><strong>$1 Per Pixel . 50% sponsorship to Drawings</strong></span></td>
</tr>
</tbody>
</table>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding: 5px 0px 0px 0px;" align="left" valign="middle"><span style="font-size: 14px; line-height: 20px; color: #333333; font-family: Arial, sans-serif;">2016 milliondollardrawings</span></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
';




// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers
$headers .= 'To: milliondollardrawings <mail-noreply@milliondollardrawings.com>, milliondollardrawings<milliondollardrawings@example.com>' . "\r\n";
$headers .= 'From: mail-noreply@milliondollardrawings.com' . "\r\n";
$headers .= 'Cc: milliondollardrawings@example.com' . "\r\n";
$headers .= 'Bcc: milliondollardrawingsnew@example.com' . "\r\n";

// Mail it
 mail($to, $subject, $message, $headers);

//exit;
if(mail)
{
?>
<script>
alert('Mail Sent Successfully');
</script>
<?php
}


 }





$message = "Drawing Update Sucesfull";
echo "<script type='text/javascript'>alert('$message');window.location.href='alldrawing.php';</script>";
//header('location:addteamleaders.php');
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Million Dollar Drawings</title>
  <!-- Bootstrap Styles-->
  <link href="assets/css/bootstrap.css" rel="stylesheet" />
  <!-- FontAwesome Styles-->
  <link href="assets/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom Styles-->
  <link href="assets/css/custom-styles.css" rel="stylesheet" />
  <!-- Google Fonts-->
  <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
  <!---- Additional Start --->
  <script src='https://cdn.tinymce.com/4/tinymce.min.js'></script>
  <!--<script src="https://tinymce.cachefly.net/4.3/tinymce.min.js"></script>-->
  <script>
  tinymce.init({
    selector: '#mytextarea',
	plugins: "image code table"
  });
  </script>
  <!--- Additional End --->
  </head>
  <body>
<div id="wrapper"> 
    <!--/. NAV TOP  -->
    <?php include('menudash.php'); ?>
    <!-- /. NAV SIDE  -->
    <div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
        <div class="col-md-6">
            <h1 class="page-header"> Drawing Management </h1>
          </div>
      </div>
        <!-- /. ROW  -->
        <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
            <div class="panel-body">
                <div class="row">
                <div class="col-lg-6">
                    <form method="post" action="" enctype="multipart/form-data">
                    <?php
                            $sql=mysql_query("select * from mp_drawings where id='{$_GET['id']}'");
$row=mysql_fetch_array($sql);
?>
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">User Name </label>
                        <?php $ui=$row['user_id'];
							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");
while ($row77 = mysql_fetch_array($result77)) 
{
		 $username = $row77['first_name']; 
		  $email = $row77['email']; 
		 
}	
?>
                        <input type="text" class="form-control" name="user_id" id="inputSuccess" value="<?php echo $username;?>" readonly>
                         <input type="hidden" class="form-control" name="username" id="inputSuccess" value="<?php echo $username;?>" readonly>
                           <input type="hidden" class="form-control" name="email" id="inputSuccess" value="<?php echo $email;?>" readonly>
                      </div>
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Theme Id</label>
                        <?php $ti=$row['theme_id'];
							  $result88 = mysql_query("SELECT * FROM mp_themes WHERE id ='$ti'");
while ($row88 = mysql_fetch_array($result88)) 
{
		 $themename = $row88['name']; 
}	
?>
                        <input type="text" class="form-control" name="theme_id" id="inputSuccess" value="<?php echo $themename;?>" readonly>
                      </div>
                      
                      
                      
                        
                      
                      
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Drawing Image Status *</label>
                        <?php $ds=$row['status']; ?>
                        <select name="status" class="form-control" id="types" required>
                        <option <?php if($ds=='') { echo $ds='selected = "selected"'; } ?>>Drawing Image Status</option>
                        <option <?php if($ds=='0') { echo $ds='selected = "selected"';	 } ?> value="0">Active</option>
                        <option <?php if($ds=='1') { echo $ds='selected = "selected"';	 } ?> value="1">Inactive</option>
                      </select>
                      </div>
                      
                      <div class="form-group has-success">
                      <input type="text"  name="reasonforblock" class="form-control"  id="InActive"   value="<?php echo $row['reasonforblock'];?>"  placeholder="Reason For Block" />
                    </div>
                    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" ></script> 
                    <script type="text/javascript">
$(document).ready(function() {
$('#types').change(function(){
if($('#types').val() == '1')
   {
   $('#InActive').css('display', 'block'); 
      }
else
   {
   $('#InActive').css('display', 'none');
   }
});
});
</script>
                    
                    <?php if($ds=='1') { ?>
                    <div class="form-group has-success">
                      <input type="text"  name="reasonforblock" class="form-control"  id="InActive" value="<?php echo $row['reasonforblock'];?>"  placeholder="Reason For Block" />
                    </div>
                    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" ></script> 
                    <script type="text/javascript">
$(document).ready(function() {
$('#types').change(function(){
if($('#types').val() == '1')
   {
   $('#InActive').css('display', 'block'); 
      }
else
   {
   $('#InActive').css('display', 'none');
   }
});
});
</script>
                    <?php } ?>
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Drawing Title *</label>
                        <input type="text" class="form-control" name="title" id="inputSuccess" value="<?php echo $row['title'];?>" readonly>
                      </div>
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Drawing Description *</label>
                        <textarea id="mytextarea" name="description" value="<?php echo $row['description'];?>" readonly><?php echo $row['description'];?></textarea>
                      </div>
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">IP Address</label>
                        <input type="text" class="form-control" name="ip_address" id="inputSuccess" value="<?php echo $row['ip_address'];?>" readonly>
                      </div>
                    <div class="form-group">
                        <label class="control-label" for="inputSuccess"  >Drawing Image</label>
                        <?php $pi=$row['drawing_image']; ?>
                        <img src="images/drawings/<?php echo $row['drawing_image']; ?>" width="60px" height="60px" />
                        <input type="file" name="drawing_image" value="<?php //echo $row['drawing_image']; ?>" id="inputSuccess" style="display:none !important;">
                      </div>
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Drawing Size</label>
                        <input type="text" class="form-control" name="drawing_size" id="inputSuccess" value="<?php echo $row['drawing_size'];?>" readonly>
                      </div>
                   <!-- <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Like Count</label>
                        <input type="text" class="form-control" name="like_count" id="inputSuccess" value="<?php //echo $row['like_count'];?>" readonly>
                      </div>-->
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Proof File</label>
                        <input type="text" class="form-control" name="proof_file" id="inputSuccess" readonly style="display:none !important" value="<?php echo $row['proof_file'];?>" >
                        <a href="<?php echo $row['proof_file'];?>" target="_blank"><?php echo $row['proof_file'];?></a> </div>
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Create Date</label>
                        <input type="text" class="form-control" name="is_watermark" id="inputSuccess" value="<?php echo $row['created_at'];?>" readonly>
                      </div>
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Sponsor Id</label>
                        <input type="text" class="form-control" name="is_sponsored" id="inputSuccess" value="<?php echo $row['is_sponsored'];?>" readonly>
                      </div>
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Likes </label>
                        <input type="text" class="form-control" name="likes" id="inputSuccess" value="<?php echo $row['likes'];?>" readonly>
                      </div>
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Reports</label>
                        <input type="text" class="form-control" name="reports" id="inputSuccess" value="<?php echo $row['reports'];?>" readonly>
                      </div>
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Clicks</label>
                        <input type="text" class="form-control" name="clicks" id="inputSuccess" value="<?php echo $row['clicks'];?>" readonly>
                      </div>
                    <div class="form-group has-success">
                        <label class="control-label" for="inputSuccess">Volunteer ID</label>
                        <input type="text" class="form-control" name="volunteer_id" id="inputSuccess" value="MDD<?php echo $row['volunteer_id'];?>" readonly>
                      </div>
                    <button class="btn btn-default" type="submit" value="update" name="update">Update</button>
                  </form>
                  </div>
              </div>
                <!-- /.col-lg-6 (nested) --> 
                <!-- /.col-lg-6 (nested) --> 
              </div>
            <!-- /.row (nested) --> 
          </div>
            <!-- /.panel-body --> 
          </div>
        <!-- /.panel --> 
      </div>
        <!-- /.col-lg-12 --> 
      </div>
    <footer>
        <p>All Right Reserved. Developed By: <a href="#"> Way2winsoftware.com</a></p>
      </footer>
  </div>
    <!-- /. PAGE INNER  --> 
  </div>
<!-- /. PAGE WRAPPER  -->
</div>
<!-- /. WRAPPER  --> 
<!-- JS Scripts--> 
<!-- jQuery Js --> 
<script src="assets/js/jquery-1.10.2.js"></script> 
<!-- Bootstrap Js --> 
<script src="assets/js/bootstrap.min.js"></script> 
<!-- Metis Menu Js --> 
<script src="assets/js/jquery.metisMenu.js"></script> 
<!-- Custom Js --> 
<script src="assets/js/custom-scripts.js"></script>
</body>
</html>
