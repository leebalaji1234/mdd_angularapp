<?php 

include('config.php');



?>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

  <head>

  <meta charset="utf-8" />

  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <title>Million Dollar Drawings</title>

  <!-- Bootstrap Styles-->

  <link href="assets/css/bootstrap.css" rel="stylesheet" />

  <!-- FontAwesome Styles-->

  <link href="assets/css/font-awesome.css" rel="stylesheet" />

  <!-- Custom Styles-->

  <link href="assets/css/custom-styles.css" rel="stylesheet" />

  <!-- Google Fonts-->

  <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

  

  <!---- Additional Start --->

  <script src='https://cdn.tinymce.com/4/tinymce.min.js'></script>

  <!--<script src="https://tinymce.cachefly.net/4.3/tinymce.min.js"></script>-->

  <script>

  tinymce.init({

    selector: '#mytextarea',

	plugins: "image code table"



  });

  </script>

  <!--- Additional End --->

  <script type="text/javascript" src="http://code.jquery.com/jquery-1.7.1.js"></script>

  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.js"></script>

  <link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.17/themes/base/jquery-ui.css">

  </head>

  <body>

<div id="wrapper"> 

    <!--/. NAV TOP  -->

    <?php include('menudash.php'); ?>

    <!-- /. NAV SIDE  -->

    <div id="page-wrapper" >

    <div id="page-inner">

        <div class="row"> 

        

      </div>

        <!-- /. ROW  -->

        <div class="row">

        <div class="col-lg-12">

            <div class="panel panel-default">

            <div class="panel-heading"><!-- Add New User-->

                <div class="panel-body">

                <div class="row">

                    <div class="col-lg-12"> 

                    <!--- Today  START --->

                    <style>

 .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td

 {

	 padding: 5px !important;

 }

 </style>

                    <?php					

					error_reporting(0);					

					/// TODAY					

					$today=$_GET['date'];

					$dayt1=$_GET['tspo'];				

					$dayt2=$_GET['ent'];				

					$dayt3=$_GET['tdt'];				

					$dayt4=$_GET['tvolun'];					

					/// ONE WEEK					

				 $oneweek1=$_GET['date1'];

				 $oneweek2=$_GET['date2'];				 				

    			  $dayoneweek1=$_GET['owspo'];

				 $dayoneweek2=$_GET['owent'];

				 $dayoneweek3=$_GET['owdt'];

				 $dayoneweek4=$_GET['owvolun'];				 

				 /// ONE Month				 

				  $onemonth1=$_GET['date1m'];

				  $onemonth2=$_GET['date2m'];

				  $dayonemonth1=$_GET['omspo'];

				  $dayonemonth2=$_GET['oment'];

				  $dayonemonth3=$_GET['omdt'];

				  $dayonemonth4=$_GET['omvolun'];				

				/// FROM TO 				 

				   $dob=$_GET['fromdate'];

				   $todate=$_GET['todate'];					   

				   $dayfrto1=$_GET['frtospo'];

				   $dayfrto2=$_GET['frtoent'];

				   $dayfrto3=$_GET['frtodt'];

				   $dayfrto4=$_GET['frtovolun'];				   

					?>

                    <!--- Today query START ---> 

                    <!--- Today query SPONSOR blocked START --->

                    <?php

                     if($dayt1 == 'tspo')

{

     $date_today = date('Y-m-d');	 

	//echo "SELECT * FROM mp_themes where status='0' AND date(created_at)='$date_today'";

	//echo "SELECT * FROM mp_regions where status='0' AND date(created_on)='$date_today'";

	 ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Sponsor Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

$sql="SELECT * FROM mp_regions where status='0' AND date(created_on)='$date_today'";

$result = mysql_query($sql);

//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                        <thead>

                            <tr>

                            <th>Sponsor Name</th>

                            <th>Sponsor URL</th>

                            <th>Sponsor Image</th>

                            <th>Sponsor Date</th>

                         

                          </tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo mysql_result($result, $i, 'title');?></td>

                            <td><?php echo mysql_result($result, $i, 'url');?></td>

                            <td><?php echo mysql_result($result, $i, 'image');?></td>

                           

                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>

                           

                          </tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "report.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";		

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- Today query SPONSOR blocked END ---> 

                    <!--- Today query ENTRANTS blocked START --->

                    <?php

                     if($dayt2 =='ent')

{

     $date_today = date('Y-m-d');

	 ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Entrants Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

$sql="SELECT * FROM mp_users where is_confirmed='0' AND date(created_at)='$date_today'";

$result = mysql_query($sql);

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                        <thead>

                          <thead>

                            <tr>

                              <th >Id</th>

                              <th >Email Id</th>

                              <th >First Name</th>

                              <th >Last Name</th>

                              <th >Create Date</th>

                              <th >Entrants Country</th>

                              <th >Entrants State</th>

                              <th>Entrants City</th>

                              <th>No of drawings submitted</th>

                              <th>Number of sponsors</th>

                              <th>Total Sponsor Amount</th>

                              <th>Reason For Block</th>

                            </tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo $id=mysql_result($result, $i, 'id');?></td>

                            <td><?php echo mysql_result($result, $i, 'email');?></td>

                            <td><?php echo mysql_result($result, $i, 'first_name');?></td>

                            <td><?php echo mysql_result($result, $i, 'last_name');?></td>

                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>

                            <td><?php 

							$cot=mysql_result($result, $i, 'country');

							  $result44 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");

while ($row44 = mysql_fetch_array($result44)) 

{

	echo  $countryname = $row44['name']; 

}	

?></td>

                            <td><?php 

							$st=mysql_result($result, $i, 'state');

							  $result444 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");

while ($row444 = mysql_fetch_array($result444)) 

{

	echo  $statename = $row444['name']; 

}	

?></td>

                            <td><?php 

							$ct=mysql_result($result, $i, 'city');

							  $result4444 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");

while ($row4444 = mysql_fetch_array($result4444)) 

{

	echo  $cityname = $row4444['name']; 

}	

?></td>

                            <td><?php   

 $result2 = mysql_query("select COUNT(user_id) from mp_drawings where user_id='$id'"); 

				$row2 = mysql_fetch_array($result2);

 echo $total2 = $row2[0];

 ?></td>

                            <td><?php   

 $result21 = mysql_query("select COUNT(user_id) from mp_payments where user_id='$id'"); 

				$row21 = mysql_fetch_array($result21);

 echo $total21 = $row21[0];

 ?></td>

                            <td><?php   

 $result23 = mysql_query("select COUNT(amount) from mp_payments where user_id='$id'"); 

				$row23 = mysql_fetch_array($result23);

 echo $total23 = $row23[0];

 ?></td>

  <td><?php echo mysql_result($result, $i, 'reasonforblock');?></td>

 

                           

                          </tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";		

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- Today query  ENTRANTS blocked END ---> 

                    <!--- Today query Drawings blocked START --->

                    <?php

                     if($dayt3 =='tdt')

{

     $date_today = date('Y-m-d');	 

	//echo "SELECT * FROM mp_drawings where status='0' AND date(created_at)='$date_today'";

	 ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Drawings Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

$sql="SELECT * FROM mp_drawings where status='1' AND date(created_at)='$date_today'";

$result = mysql_query($sql);

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                         <thead>

                            <tr>

                            <th>Id</th>

                            <th>User Name</th>

                            <th>Theme Name</th>

                            <th>Title</th>

                            <th>Description</th>

                            <th>Create Date</th>

                            <th>Likes</th>

                            <th>Reports</th>

                            <th>Clicks</th>

                            <th>Volunteer Id</th>

                            <th>Sponsor Amount</th>

                            <th>Sponsor Name</th>

                            <th>Reason For Block</th>

                          </tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                             <tr>

                            <td><?php echo mysql_result($result, $i, 'id');?></td>

                            <td><?php  mysql_result($result, $i, 'user_id');

                            $ui=mysql_result($result, $i, 'user_id');

							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");

while ($row77 = mysql_fetch_array($result77)) 

{

	echo $username = $row77['first_name']; 

}	

?></td>

                            <td><?php mysql_result($result, $i, 'id');

                              $ti=mysql_result($result, $i, 'id');

							  $result88 = mysql_query("SELECT * FROM mp_themes WHERE id ='$ti'");

while ($row88 = mysql_fetch_array($result88)) 

{

	echo $themename = $row88['name']; 

}	

?></td>

                            <td><?php echo mysql_result($result, $i, 'title');?></td>

                            <td><?php echo mysql_result($result, $i, 'description');?></td>

                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>

                            <td><?php echo mysql_result($result, $i, 'likes');?></td>

                            <td><?php echo mysql_result($result, $i, 'reports');?></td>

                            <td><?php echo mysql_result($result, $i, 'clicks');?></td>

                            <td><?php echo mysql_result($result, $i, 'volunteer_id');?></td>

                            <td><?php mysql_result($result, $i, 'id');

                              $di=mysql_result($result, $i, 'id');

							  $result98 = mysql_query("SELECT * FROM mp_payments WHERE drawing_id ='$di'");

while ($row98 = mysql_fetch_array($result98)) 

{

	echo $sponsoramount = $row98['amount']; 

	$regionid= $row98['region_id'];

}	

?></td>

<td><?php 

							  $result97 = mysql_query("SELECT * FROM mp_themes WHERE region_id ='$regionid'");

while ($row97 = mysql_fetch_array($result97)) 

{

	echo $sponsorname = $row97['title']; 

}	

?></td>

<td><?php echo mysql_result($result, $i, 'reasonforblock');?></td>

                            

                          </tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";		

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- Today query  Drawings blocked END ---> 

                    <!--- Today query VOLUNTEER blocked START --->

                    <?php

                     if($dayt4 =='tvolun')

{

     $date_today = date('Y-m-d');	

	 ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Volunteer Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

$sql="SELECT * FROM mp_volunteers where status='0' AND date(created_at)='$date_today'";

$result = mysql_query($sql);

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                        <thead>

                            <tr>

                            <th>Id</th>

                            <th>Name</th>

                            <th>E Mail Id</th>

                            <th>Phone</th>

                            <th>Create Date</th>

                            <th >Volunteer Country</th>

                            <th >Volunteer State</th>

                            <th>Volunteer City</th>

                            <th>No of Entrants Introduced</th>

                            <th>Reason For Block</th>

                          </tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo mysql_result($result, $i, 'id');?></td>

                            <td><?php echo  mysql_result($result, $i, 'name');

?></td>

                            <td><?php echo mysql_result($result, $i, 'email'); ?></td>

                            <td><?php echo mysql_result($result, $i, 'phone');?></td>

                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>

                             <td><?php 

							$cot=mysql_result($result, $i, 'country');

							  $result99 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");

while ($row99 = mysql_fetch_array($result99)) 

{

	echo  $countryname = $row99['name']; 

}	

?></td>

                            <td><?php 

							$st=mysql_result($result, $i, 'state');

							  $result999 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");

while ($row999 = mysql_fetch_array($result999)) 

{

	echo  $statename = $row999['name']; 

}	

?></td>

                            <td><?php 

							$ct=mysql_result($result, $i, 'city');

							  $result9999 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");

while ($row9999 = mysql_fetch_array($result9999)) 

{

	echo  $cityname = $row9999['name']; 

}	

?></td>

<td><?php $entco=mysql_result($result, $i, 'id');

//echo "SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'";

$result9988 = mysql_query("SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'");

				$row9988 = mysql_fetch_array($result9988);

  echo $total9988 = $row9988[0];

?></td>

<td><?php echo mysql_result($result, $i, 'reasonforblock');?></td>

                           

                          </tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";		

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- Today query  VOLUNTEER blocked END ---> 

                    <!--- Today query END ---> 

                    <!--- ONe WEEk  query START ---> 

                    <!--- ONe WEEk  query Sponsor blocked START --->

                    <?php

                    if($dayoneweek1 == 'owspo')

{

     $date_today = date('Y-m-d');

	 $date_oneweek = strtotime("-1 week"); 

 $date_oneweek = date('Y-m-d', $date_oneweek);	

		

	 ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Sponsor Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

$sql="SELECT * FROM mp_regions where status='0' AND  date(created_on) >= '$date_oneweek' AND date(created_on) <= '$date_today'";

$result = mysql_query($sql);

//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                        <thead>

                            <tr>

                            <th>Sponsor Name</th>

                            <th>Sponsor URL</th>

                            <th>Sponsor Image</th>

                            <th>Sponsor Date</th></tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo mysql_result($result, $i, 'title');?></td>

                            <td><?php echo mysql_result($result, $i, 'url');?></td>

                            <td><?php echo mysql_result($result, $i, 'image');?></td>

                            <td><?php echo mysql_result($result, $i, 'created_on');?></td></tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";		

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- ONe WEEk  query Sponsor blocked END ---> 

                    <!--- ONe WEEk  query ENTRANT blocked START --->

                    <?php

                    if($dayoneweek2 == 'owent')

{

     $date_today = date('Y-m-d');

	 $date_oneweek = strtotime("-1 week"); 

 $date_oneweek = date('Y-m-d', $date_oneweek);	 

	//echo "SELECT * FROM mp_users where is_confirmed='0' AND  date(created_at) >= '$date_oneweek' AND (created_at) <= '$date_today'";	

	 ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Entrants Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

$sql="SELECT * FROM mp_users where is_confirmed='0' AND  date(created_at) >= '$date_oneweek' AND date(created_at) <= '$date_today'";

$result = mysql_query($sql);

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                        <thead>

                            <tr>

                            <th >Id</th>

                            <th >Email Id</th>

                            <th >First Name</th>

                            <th >Last Name</th>

                            <th >Create Date</th>

                            <th >Entrants Country</th>

                            <th >Entrants State</th>

                            <th>Entrants City</th>

                            <th>No of drawings submitted</th>

                            <th>Number of sponsors</th>

                            <th>Total Sponsor Amount</th>

                            <th>Reason For Block</th>

                          </tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo $id=mysql_result($result, $i, 'id');?></td>

                            <td><?php echo mysql_result($result, $i, 'email');?></td>

                            <td><?php echo mysql_result($result, $i, 'first_name');?></td>

                            <td><?php echo mysql_result($result, $i, 'last_name');?></td>

                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>

                            <td><?php 

							$cot=mysql_result($result, $i, 'country');

							  $result44 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");

while ($row44 = mysql_fetch_array($result44)) 

{

	echo  $countryname = $row44['name']; 

}	

?></td>

                            <td><?php 

							$st=mysql_result($result, $i, 'state');

							  $result444 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");

while ($row444 = mysql_fetch_array($result444)) 

{

	echo  $statename = $row444['name']; 

}	

?></td>

                            <td><?php 

							$ct=mysql_result($result, $i, 'city');

							  $result4444 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");

while ($row4444 = mysql_fetch_array($result4444)) 

{

	echo  $cityname = $row4444['name']; 

}	

?></td>

                            <td><?php   

 $result2 = mysql_query("select COUNT(user_id) from mp_drawings where user_id='$id'"); 

				$row2 = mysql_fetch_array($result2);

 echo $total2 = $row2[0];

 ?></td>

                            <td><?php   

 $result21 = mysql_query("select COUNT(user_id) from mp_payments where user_id='$id'"); 

				$row21 = mysql_fetch_array($result21);

 echo $total21 = $row21[0];

 ?></td>

                            <td><?php   

 $result23 = mysql_query("select COUNT(amount) from mp_payments where user_id='$id'"); 

				$row23 = mysql_fetch_array($result23);

 echo $total23 = $row23[0];

 ?></td>

 <td><?php echo mysql_result($result, $i, 'reasonforblock');?></td>

                            

                            </tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";		

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- One WEEk query ENTRANT blocked END ---> 

                    <!--- ONe WEEk  query Drawings blocked START --->

                    <?php

                    if($dayoneweek3 == 'owdt') 

{

     $date_today = date('Y-m-d');

	 $date_oneweek = strtotime("-1 week"); 

 $date_oneweek = date('Y-m-d', $date_oneweek);	

	

	 ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Drawings Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

$sql="SELECT * FROM mp_drawings where status='1' AND  date(created_at) >= '$date_oneweek' AND date(created_at) <= '$date_today'";

$result = mysql_query($sql);

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                         <thead>

                            <tr>

                            <th>Id</th>

                            <th>User Name</th>

                            <th>Theme Name</th>

                            <th>Title</th>

                            <th>Description</th>

                            <th>Create Date</th>

                            

                            <th>Likes</th>

                            <th>Reports</th>

                            <th>Clicks</th>

                            <th>Volunteer Id</th>

                            <th>Sponsor Amount</th>

                            <th>Sponsor Name</th>

                            <th>Reason For Block</th>

                            </tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                             <tr>

                            <td><?php echo mysql_result($result, $i, 'id');?></td>

                            <td><?php  mysql_result($result, $i, 'user_id');

                            $ui=mysql_result($result, $i, 'user_id');

							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");

while ($row77 = mysql_fetch_array($result77)) 

{

	echo $username = $row77['first_name']; 

}	

?></td>

                            <td><?php mysql_result($result, $i, 'id');

                              $ti=mysql_result($result, $i, 'id');

							  $result88 = mysql_query("SELECT * FROM mp_themes WHERE id ='$ti'");

while ($row88 = mysql_fetch_array($result88)) 

{

	echo $themename = $row88['name']; 

}	

?></td>

                            <td><?php echo mysql_result($result, $i, 'title');?></td>

                            <td><?php echo mysql_result($result, $i, 'description');?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'likes');?></td>

                            <td><?php echo mysql_result($result, $i, 'reports');?></td>

                            <td><?php echo mysql_result($result, $i, 'clicks');?></td>

                            <td><?php echo mysql_result($result, $i, 'volunteer_id');?></td>

                            <td><?php mysql_result($result, $i, 'id');

                              $di=mysql_result($result, $i, 'id');

							  $result98 = mysql_query("SELECT * FROM mp_payments WHERE drawing_id ='$di'");

while ($row98 = mysql_fetch_array($result98)) 

{

	echo $sponsoramount = $row98['amount']; 

	$regionid= $row98['region_id'];

}	

?></td>

<td><?php 

							  $result97 = mysql_query("SELECT * FROM mp_themes WHERE region_id ='$regionid'");

while ($row97 = mysql_fetch_array($result97)) 

{

	echo $sponsorname = $row97['title']; 

}	

?></td>

<td><?php echo mysql_result($result, $i, 'reasonforblock');?></td></tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";		

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- One WEEk query Drawings blocked  END ---> 

                    <!--- ONe WEEk  query Volunteer blocked START --->

                    <?php

                    if($dayoneweek4 == 'owvolun') 

{

     $date_today = date('Y-m-d');

	 $date_oneweek = strtotime("-1 week"); 

 $date_oneweek = date('Y-m-d', $date_oneweek);	 	

	

	 ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Volunteer Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

$sql="SELECT * FROM mp_volunteers where status='0' AND  date(created_at) >= '$date_oneweek' AND date(created_at) <= '$date_today'";

$result = mysql_query($sql);



$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                       <thead>

                            <tr>

                            <th>Id</th>

                            <th>Name</th>

                            <th>E Mail Id</th>

                            <th>Phone</th>

                            <th>Create Date</th>

                            <th >Volunteer Country</th>

                            <th >Volunteer State</th>

                            <th>Volunteer City</th>

                            <th>No of Entrants Introduced</th>

                            <th>Reason For Block</th>

                            

                            

                            </tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo mysql_result($result, $i, 'id');?></td>

                            <td><?php echo  mysql_result($result, $i, 'name');

                            ?></td>

                            <td><?php echo mysql_result($result, $i, 'email'); ?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'phone');?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>

                             <td><?php 

							$cot=mysql_result($result, $i, 'country');

							  $result99 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");

while ($row99 = mysql_fetch_array($result99)) 

{

	echo  $countryname = $row99['name']; 

}	

?></td>

                            <td><?php 

							$st=mysql_result($result, $i, 'state');

							  $result999 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");

while ($row999 = mysql_fetch_array($result999)) 

{

	echo  $statename = $row999['name']; 

}	

?></td>

                            <td><?php 

							$ct=mysql_result($result, $i, 'city');

							  $result9999 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");

while ($row9999 = mysql_fetch_array($result9999)) 

{

	echo  $cityname = $row9999['name']; 

}	

?></td>

<td><?php $entco=mysql_result($result, $i, 'id');



$result9988 = mysql_query("SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'");

				$row9988 = mysql_fetch_array($result9988);

  echo $total9988 = $row9988[0];

?></td>

<td><?php echo mysql_result($result, $i, 'reasonforblock');?></td>

                            

                            </tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";		

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- One WEEk query Volunteer blocked  END ---> 

                    <!--- One WEEk query END ---> 

                    <!--- ONE MONTH query  START ---> 

                    <!--- ONE MONTH query Sponsor blocked  START --->

                    <?php

                     if($dayonemonth1 == 'omspo')

{

     $date_today = date('Y-m-d');

 $date_onemonth = strtotime("-1 month");

 $date_onemonth = date('Y-m-d', $date_onemonth); 

 	

	 ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Sponsor Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

$sql="SELECT * FROM mp_regions where status='0' AND date(created_on) >= '$date_onemonth' AND date(created_on) <= '$date_today'";

$result = mysql_query($sql);

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                        <thead>

                            <tr>

                            <th>Sponsor Name</th>

                            <th>Sponsor URL</th>

                            <th>Sponsor Image</th>

                            <th>Sponsor Date</th></tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo mysql_result($result, $i, 'title');?></td>

                            <td><?php echo mysql_result($result, $i, 'url');?></td>

                            <td><?php echo mysql_result($result, $i, 'image');?></td>

                            <td><?php echo mysql_result($result, $i, 'created_on');?></td></tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";		

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- ONE MONTH query Sponsor blocked  END ---> 

                    <!--- ONE MONTH query Entrant blocked START --->

                    <?php

                     if($dayonemonth2 =='oment')

{

     $date_today = date('Y-m-d');

 $date_onemonth = strtotime("-1 month");

 $date_onemonth = date('Y-m-d', $date_onemonth); 

 	//echo "SELECT * FROM mp_users where is_confirmed='0' AND date(created_at) >= '$date_onemonth' AND (created_at) <= '$date_today'";	

	 ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Entrants Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

$sql="SELECT * FROM mp_users where is_confirmed='0' AND date(created_at) >= '$date_onemonth' AND date(created_at) <= '$date_today'";

$result = mysql_query($sql);

//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                        <thead>

                            <tr>

                            <th >Id</th>

                            <th >Email Id</th>

                            <th >First Name</th>

                            <th >Last Name</th>

                            <th >Create Date</th>

                            <th >Entrants Country</th>

                            <th >Entrants State</th>

                            <th>Entrants City</th>

                            <th>No of drawings submitted</th>

                            <th>Number of sponsors</th>

                            <th>Total Sponsor Amount</th>

                            <th>Reason For Block</th></tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo $id=mysql_result($result, $i, 'id');?></td>

                            <td><?php echo mysql_result($result, $i, 'email');?></td>

                            <td><?php echo mysql_result($result, $i, 'first_name');?></td>

                            <td><?php echo mysql_result($result, $i, 'last_name');?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>

                            <td><?php 

							$cot=mysql_result($result, $i, 'country');

							  $result44 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");

while ($row44 = mysql_fetch_array($result44)) 

{

	echo  $countryname = $row44['name']; 

}	

?></td>

                            <td><?php 

							$st=mysql_result($result, $i, 'state');

							  $result444 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");

while ($row444 = mysql_fetch_array($result444)) 

{

	echo  $statename = $row444['name']; 

}	

?></td>

                            <td><?php 

							$ct=mysql_result($result, $i, 'city');

							  $result4444 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");

while ($row4444 = mysql_fetch_array($result4444)) 

{

	echo  $cityname = $row4444['name']; 

}	

?></td>

                            <td><?php   //echo "select COUNT(user_id) from mp_drawings where user_id='$id'";

 $result2 = mysql_query("select COUNT(user_id) from mp_drawings where user_id='$id'"); 

				$row2 = mysql_fetch_array($result2);

 echo $total2 = $row2[0];

 ?></td>

                            <td><?php   

 $result21 = mysql_query("select COUNT(user_id) from mp_payments where user_id='$id'"); 

				$row21 = mysql_fetch_array($result21);

 echo $total21 = $row21[0];

 ?></td>

                            <td><?php   

 $result23 = mysql_query("select COUNT(amount) from mp_payments where user_id='$id'"); 

				$row23 = mysql_fetch_array($result23);

 echo $total23 = $row23[0];

 ?></td>

 <td><?php echo mysql_result($result, $i, 'reasonforblock');?></td>

                            

                            </tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";		

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- ONE MONTH query Entrant blocked  END ---> 

                    <!--- ONE MONTH query Drawings blocked START --->

                    <?php

                     if($dayonemonth3 == 'omdt')

{

     $date_today = date('Y-m-d');

 $date_onemonth = strtotime("-1 month");

 $date_onemonth = date('Y-m-d', $date_onemonth); 

 	//echo "SELECT * FROM mp_drawings where status='0' AND date(created_at) >= '$date_onemonth' AND (created_at) <= '$date_today'";	

	 ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Drawings Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

$sql="SELECT * FROM mp_drawings where status='1' AND date(created_at) >= '$date_onemonth' AND date(created_at) <= '$date_today'";

$result = mysql_query($sql);

//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                        <thead>

                            <tr>

                            <th>Id</th>

                            <th>User Name</th>

                            <th>Theme Name</th>

                            <th>Title</th>

                            <th>Description</th>

                            <th>Create Date</th>

                            

                            <th>Likes</th>

                            <th>Reports</th>

                            <th>Clicks</th>

                            <th>Volunteer Id</th>

                            <th>Sponsor Amount</th>

                            <th>Sponsor Name</th>

                            <th>Reson For Block</th>

                            </tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                           <tr>

                            <td><?php echo mysql_result($result, $i, 'id');?></td>

                            <td><?php  mysql_result($result, $i, 'user_id');

                            $ui=mysql_result($result, $i, 'user_id');

							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");

while ($row77 = mysql_fetch_array($result77)) 

{

	echo $username = $row77['first_name']; 

}	

?></td>

                            <td><?php mysql_result($result, $i, 'id');

                              $ti=mysql_result($result, $i, 'id');

							  $result88 = mysql_query("SELECT * FROM mp_themes WHERE id ='$ti'");

while ($row88 = mysql_fetch_array($result88)) 

{

	echo $themename = $row88['name']; 

}	

?></td>

                            <td><?php echo mysql_result($result, $i, 'title');?></td>

                            <td><?php echo mysql_result($result, $i, 'description');?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'likes');?></td>

                            <td><?php echo mysql_result($result, $i, 'reports');?></td>

                            <td><?php echo mysql_result($result, $i, 'clicks');?></td>

                            <td><?php echo mysql_result($result, $i, 'volunteer_id');?></td>

                            <td><?php mysql_result($result, $i, 'id');

                              $di=mysql_result($result, $i, 'id');

							  $result98 = mysql_query("SELECT * FROM mp_payments WHERE drawing_id ='$di'");

while ($row98 = mysql_fetch_array($result98)) 

{

	echo $sponsoramount = $row98['amount']; 

	$regionid= $row98['region_id'];

}	

?></td>

<td><?php 

							  $result97 = mysql_query("SELECT * FROM mp_themes WHERE region_id ='$regionid'");

while ($row97 = mysql_fetch_array($result97)) 

{

	echo $sponsorname = $row97['title']; 

}	

?></td>

<td><?php echo mysql_result($result, $i, 'reasonforblock');?></td></tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";		

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- ONE MONTH query Drawings blocked End ---> 

                    <!--- ONE MONTH query VOLUNTEER blocked START --->

                    <?php

                     if($dayonemonth4 == 'omvolun')

{

     $date_today = date('Y-m-d');

 $date_onemonth = strtotime("-1 month");

 $date_onemonth = date('Y-m-d', $date_onemonth); 

 	//echo "SELECT * FROM mp_volunteers WHERE  status='0' AND date(created_at) >= '$date_onemonth' AND (created_at) <= '$date_today'";	

	 ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Volunteer Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

$sql="SELECT * FROM mp_volunteers WHERE  status='0' AND date(created_at) >= '$date_onemonth' AND date(created_at) <= '$date_today'";

$result = mysql_query($sql);

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                        <thead>

                            <tr>

                            <th>Id</th>

                            <th>Name</th>

                            <th>E Mail Id</th>

                            <th>Phone</th>

                            <th>Create Date</th>

                            <th >Volunteer Country</th>

                            <th >Volunteer State</th>

                            <th>Volunteer City</th>

                            <th>No of Entrants Introduced</th>

                            <th>Reason For Block</th>

                            

                            

                            </tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo mysql_result($result, $i, 'id');?></td>

                            <td><?php echo  mysql_result($result, $i, 'name');

                            ?></td>

                            <td><?php echo mysql_result($result, $i, 'email'); ?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'phone');?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>

                             <td><?php 

							$cot=mysql_result($result, $i, 'country');

							  $result99 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");

while ($row99 = mysql_fetch_array($result99)) 

{

	echo  $countryname = $row99['name']; 

}	

?></td>

                            <td><?php 

							$st=mysql_result($result, $i, 'state');

							  $result999 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");

while ($row999 = mysql_fetch_array($result999)) 

{

	echo  $statename = $row999['name']; 

}	

?></td>

                            <td><?php 

							$ct=mysql_result($result, $i, 'city');

							  $result9999 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");

while ($row9999 = mysql_fetch_array($result9999)) 

{

	echo  $cityname = $row9999['name']; 

}	

?></td>

<td><?php $entco=mysql_result($result, $i, 'id');

//echo "SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'";

$result9988 = mysql_query("SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'");

				$row9988 = mysql_fetch_array($result9988);

  echo $total9988 = $row9988[0];

?></td>

<td><?php echo mysql_result($result, $i, 'reasonforblock');?></td>

                            

                            </tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";		

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- ONE MONTH query VOLUNTEER blocked END ---> 

                    <!--- One MONTH query  END ---> 

                    <!--- From TO query START ---> 

                    <!--- From TO query Sponsor blocked START --->

                    <?php

					$dob=$_GET['fromdate'];

				   $todate=$_GET['todate'];						

                     if ($dayfrto1 == 'frtospo')

{	



//save data

error_reporting(0);

 //$query1="insert into 

 $php_timestamp = time();

 

                  ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Sponsor Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

 $sql="SELECT * FROM mp_regions where status='0' AND date(created_on) >= '$dob' AND date(created_on) <= '$todate'";

$result = mysql_query($sql);

//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                        <thead>

                            <tr>

                            <th>Sponsor Name</th>

                            <th>Sponsor URL</th>

                            <th>Sponsor Image</th>

                            <th>Sponsor Date</th></tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo mysql_result($result, $i, 'title');?></td>

                            <td><?php echo mysql_result($result, $i, 'url');?></td>

                            <td><?php echo mysql_result($result, $i, 'image');?></td>

                            <td><?php echo mysql_result($result, $i, 'created_on');?></td></tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";	

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- From TO query SPONSOR blocked END ---> 

                    <!--- From TO query ENTRANT blocked START --->

                    <?php

					$dob=$_GET['fromdate'];

				   $todate=$_GET['todate'];						

                     if ($dayfrto2 == 'frtoent')

{	



//save data

error_reporting(0);

 $php_timestamp = time();

                  ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Entrants Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

 $sql="SELECT * FROM mp_users where is_confirmed='0' AND date(created_at) >= '$dob' AND date(created_at) <= '$todate'";

$result = mysql_query($sql);

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                        <thead>

                            <tr>

                            <th >Id</th>

                            <th >Email Id</th>

                            <th >First Name</th>

                            <th >Last Name</th>

                            <th >Create Date</th>

                            <th >Entrants Country</th>

                            <th >Entrants State</th>

                            <th>Entrants City</th>

                            <th>No of drawings submitted</th>

                            <th>Number of sponsors</th>

                            <th>Total Sponsor Amount</th>

                            <th>Reason For Block</th></tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo $id=mysql_result($result, $i, 'id');?></td>

                            <td><?php echo mysql_result($result, $i, 'email');?></td>

                            <td><?php echo mysql_result($result, $i, 'first_name');?></td>

                            <td><?php echo mysql_result($result, $i, 'last_name');?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>

                            <td><?php 

							$cot=mysql_result($result, $i, 'country');

							  $result44 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");

while ($row44 = mysql_fetch_array($result44)) 

{

	echo  $countryname = $row44['name']; 

}	

?></td>

                            <td><?php 

							$st=mysql_result($result, $i, 'state');

							  $result444 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");

while ($row444 = mysql_fetch_array($result444)) 

{

	echo  $statename = $row444['name']; 

}	

?></td>

                            <td><?php 

							$ct=mysql_result($result, $i, 'city');

							  $result4444 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");

while ($row4444 = mysql_fetch_array($result4444)) 

{

	echo  $cityname = $row4444['name']; 

}	

?></td>

                            <td><?php   //echo "select COUNT(user_id) from mp_drawings where user_id='$id'";

 $result2 = mysql_query("select COUNT(user_id) from mp_drawings where user_id='$id'"); 

				$row2 = mysql_fetch_array($result2);

 echo $total2 = $row2[0];

 ?></td>

                            <td><?php   

 $result21 = mysql_query("select COUNT(user_id) from mp_payments where user_id='$id'"); 

				$row21 = mysql_fetch_array($result21);

 echo $total21 = $row21[0];

 ?></td>

                            <td><?php   

 $result23 = mysql_query("select COUNT(amount) from mp_payments where user_id='$id'"); 

				$row23 = mysql_fetch_array($result23);

 echo $total23 = $row23[0];

 ?></td>

 <td><?php echo mysql_result($result, $i, 'reasonforblock');?></td>

                            

                            </tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";	

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- From TO query ENTRANT blocked END ---> 

                    <!--- From TO query DRAWING blocked START --->

                    <?php

					 $dob=$_GET['fromdate'];

				   $todate=$_GET['todate'];						

                     if ($dayfrto3 == 'frtodt')

{	



//save data

error_reporting(0);

 $php_timestamp = time();

                  ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Drawings Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

 $sql="SELECT * FROM mp_drawings where status='1' AND date(created_at) >= '$dob' AND date(created_at) <= '$todate'";

$result = mysql_query($sql);

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                         <thead>

                            <tr>

                            <th>Id</th>

                            <th>User Name</th>

                            <th>Theme Name</th>

                            <th>Title</th>

                            <th>Description</th>

                            <th>Create Date</th>

                            

                            <th>Likes</th>

                            <th>Reports</th>

                            <th>Clicks</th>

                            <th>Volunteer Id</th>

                            <th>Sponsor Amount</th>

                            <th>Sponsor Name</th>

                            <th>Reason For Block</th>

                            </tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo mysql_result($result, $i, 'id');?></td>

                            <td><?php  mysql_result($result, $i, 'user_id');

                            $ui=mysql_result($result, $i, 'user_id');

							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");

while ($row77 = mysql_fetch_array($result77)) 

{

	echo $username = $row77['first_name']; 

}	

?></td>

                            <td><?php mysql_result($result, $i, 'id');

                              $ti=mysql_result($result, $i, 'id');

							  $result88 = mysql_query("SELECT * FROM mp_themes WHERE id ='$ti'");

while ($row88 = mysql_fetch_array($result88)) 

{

	echo $themename = $row88['name']; 

}	

?></td>

                            <td><?php echo mysql_result($result, $i, 'title');?></td>

                            <td><?php echo mysql_result($result, $i, 'description');?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'likes');?></td>

                            <td><?php echo mysql_result($result, $i, 'reports');?></td>

                            <td><?php echo mysql_result($result, $i, 'clicks');?></td>

                            <td><?php echo mysql_result($result, $i, 'volunteer_id');?></td>

                            <td><?php mysql_result($result, $i, 'id');

                              $di=mysql_result($result, $i, 'id');

							  $result98 = mysql_query("SELECT * FROM mp_payments WHERE drawing_id ='$di'");

while ($row98 = mysql_fetch_array($result98)) 

{

	echo $sponsoramount = $row98['amount']; 

	$regionid= $row98['region_id'];

}	

?></td>

<td><?php 

							  $result97 = mysql_query("SELECT * FROM mp_themes WHERE region_id ='$regionid'");

while ($row97 = mysql_fetch_array($result97)) 

{

	echo $sponsorname = $row97['title']; 

}	

?></td>

<td><?php echo mysql_result($result, $i, 'reasonforblock');?></td></tr>

                            <?php }  ?>

                            

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";	

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- From TO query DRAWING END ---> 

                    <!--- From TO query VOLUNTEER START --->

                    <?php

					 $dob=$_GET['fromdate'];

				   $todate=$_GET['todate'];						

                     if ($dayfrto4 == 'frtovolun')

{	



//save data

error_reporting(0);

 $php_timestamp = time();

                  ?>

                    <div class="col-md-12">

                        <h1 class="page-header"> Volunteer Report </h1>

                      </div>

                    <div class="table-responsive">

                        <table class="table table-striped table-bordered table-hover">

                        <?php

$per_page =30;  // number of results to show per page

 $sql="SELECT * FROM mp_volunteers where status='0' AND date(created_at) >= '$dob' AND date(created_at) <= '$todate'";

$result = mysql_query($sql);

$total_results = mysql_num_rows($result);

$total_pages = ceil($total_results / $per_page);//total pages we going to have

if($total_results>0)

{

	?>

                        <thead>

                            <tr>

                            <th>Id</th>

                            <th>Name</th>

                            <th>E Mail Id</th>

                            <th>Phone</th>

                            <th>Create Date</th>

                            <th >Volunteer Country</th>

                            <th >Volunteer State</th>

                            <th>Volunteer City</th>

                            <th>No of Entrants Introduced</th>

                            <th>Reson For Block</th>

                            

                            

                            </tr>

                          </thead>

                        <tbody>

                            <?php

//-------------if page is setcheck------------------//

if (isset($_GET['page']))

 {	 

     $show_page = $_GET['page'];   

	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page

    if ($show_page > 0 && $show_page <= $total_pages) {

        $start = ($show_page - 1) * $per_page;

        $end = $start + $per_page;

    } else {

        // error - show first set of results

        $start = 0;              

        $end = $per_page;

    }

} else {

    // if page isn't set, show first set of results

    $start = 0;

    $end = $per_page;

}

// display pagination

$page = isset($_GET['page']);  

$tpages=$total_pages;

if ($page <= 0)

    $page = 1; 

	//$query=mysql_query("select * from users");

	for ($i = $start; $i < $end; $i++)  

	{

		if ($i == $total_results)

		 {

		 break;

		 }

	?>

                            <tr>

                            <td><?php echo mysql_result($result, $i, 'id');?></td>

                            <td><?php echo  mysql_result($result, $i, 'name');

                            ?></td>

                            <td><?php echo mysql_result($result, $i, 'email'); ?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'phone');?></td>

                            

                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>

                             <td><?php 

							$cot=mysql_result($result, $i, 'country');

							  $result99 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");

while ($row99 = mysql_fetch_array($result99)) 

{

	echo  $countryname = $row99['name']; 

}	

?></td>

                            <td><?php 

							$st=mysql_result($result, $i, 'state');

							  $result999 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");

while ($row999 = mysql_fetch_array($result999)) 

{

	echo  $statename = $row999['name']; 

}	

?></td>

                            <td><?php 

							$ct=mysql_result($result, $i, 'city');

							  $result9999 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");

while ($row9999 = mysql_fetch_array($result9999)) 

{

	echo  $cityname = $row9999['name']; 

}	

?></td>

<td><?php $entco=mysql_result($result, $i, 'id');

//echo "SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'";

$result9988 = mysql_query("SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'");

				$row9988 = mysql_fetch_array($result9988);

  echo $total9988 = $row9988[0];

?></td>

<td><?php echo mysql_result($result, $i, 'reasonforblock');?></td>

                            

                            </tr>

                            <?php }  ?>

                            <tr>

                            <td colspan="12" align="right"><?php 

	 $reload = "report.php" . "?tpages=" . $tpages;

                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">

    <ul class="pagination">';

                    if ($total_pages > 1) {

						error_reporting(0);

                        echo paginate($reload, $show_page, $total_pages);

                    } 

                    echo " </ul>

    </div>";

	?>

                                <?php

}

else

{

echo "No records found";	

}

?></td>

                          </tr>

                          </tbody>

                      </table>

                      </div>

                    <?php } ?>

                    <!--- From TO query VOLUNTEER blocked END ---> 

                    <!--- From TO END ---> 

                  </div>

                    <!-- /.col-lg-6 (nested) --> 

                    <!-- /.col-lg-6 (nested) --> 

                  </div>

                <!-- /.row (nested) --> 

              </div>

                <!-- /.panel-body --> 

              </div>

            <!-- /.panel --> 

          </div>

            <!-- /.col-lg-12 --> 

          </div>

        <footer>

            <p>All Right Reserved. Developed By: <a href="#"> Way2winsoftware.com</a></p>

          </footer>

      </div>

        <!-- /. PAGE INNER  --> 

      </div>

    <!-- /. PAGE WRAPPER  --> 

  </div>

  </div>

<!-- /. WRAPPER  --> 

<!-- JS Scripts--> 

<!-- jQuery Js --> 

<!--<script src="assets/js/jquery-1.10.2.js"></script>--> 

<!-- Bootstrap Js --> 

<script src="assets/js/bootstrap.min.js"></script> 

<!-- Metis Menu Js --> 

<script src="assets/js/jquery.metisMenu.js"></script> 

<!-- Custom Js --> 

<script src="assets/js/custom-scripts.js"></script>

</body>

</html>

