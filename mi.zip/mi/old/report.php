<?php 
include('config.php');
//if (!empty($_POST['submit']))
//{	
//echo $dob = mysql_real_escape_string($_POST['dob']);
//echo $todate = mysql_real_escape_string($_POST['todate']);
////save data
//error_reporting(0);
// //$query1="insert into user(user_email_id,user_status,user_type,user_password,created_date_time,last_updated_date_time,last_login_date_time,user_reset_pwd_status) values('$user_email_id','$user_status','$user_type','$user_password','$created_date_time','$last_updated_date_time','$last_login_date_time','$user_reset_pwd_status')";  
// $php_timestamp = time();
//
////echo "select * from mp_users where date(created_at)='$dob'";
//
//echo "SELECT * FROM mp_users WHERE date(created_at) >= '$dob' AND (created_at) <= '$todate'";
//
//
//
////echo  $query1="insert into mp_users(email,pass,created_at,first_name,last_name,is_confirmed,country,state,city,dob,age)values('$email','$pass','now();','$first_name','$last_name','$is_confirmed','$country','$state','$city','$dob','$age')";   
////exit;
//mysql_query($query1);
//$message = "User Added Sucesfull ";
//echo "<script type='text/javascript'>alert('$message');window.location.href='adduser.php';
//}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Million Dollar Drawings</title>
  <!-- Bootstrap Styles-->
  <link href="assets/css/bootstrap.css" rel="stylesheet" />
  <!-- FontAwesome Styles-->
  <link href="assets/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom Styles-->
  <link href="assets/css/custom-styles.css" rel="stylesheet" />
  <!-- Google Fonts-->
  <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
  <!--<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
$(document).ready(function() {    
	$("#parent_cat").change(function() {
		$(this).after('<div id="loader"><img src="img/loading.gif" alt="loading subcategory" /></div>');
		$.get('loadsubcat.php?parent_cat=' + $(this).val(), function(data) {
			$("#sub_cat").html(data);
			$('#loader').slideUp(200, function() {
				$(this).remove();
			});
		});	
    });
});
</script>-->
  <!---- Additional Start --->
  <script src='https://cdn.tinymce.com/4/tinymce.min.js'></script>
  <!--<script src="https://tinymce.cachefly.net/4.3/tinymce.min.js"></script>-->
  <script>
  tinymce.init({
    selector: '#mytextarea',
	plugins: "image code table"
	//,
//  image_list: [
//    {title: 'My image 1', value: 'http://www.tinymce.com/my1.gif'},
//    {title: 'My image 2', value: 'http://www.moxiecode.com/my2.gif'}
//  ]	
	//var text = tinyMCE.get('mytextarea').getContent(); 
  });
  </script>
  <!--- Additional End --->
  <script type="text/javascript" src="http://code.jquery.com/jquery-1.7.1.js"></script>
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.js"></script>
  <link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.17/themes/base/jquery-ui.css">
  </head>
  <body>
<div id="wrapper"> 
    <!--/. NAV TOP  -->
    <?php include('menudash.php'); ?>
    <!-- /. NAV SIDE  -->
    <div id="page-wrapper" >
    <div id="page-inner">
        <div class="row"> 
        <!-- <div class="col-md-12">
            <h1 class="page-header"> Entrants Report </h1>
          </div>--> 
      </div>
        <!-- /. ROW  -->
        <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
            <div class="panel-heading"><!-- Add New User-->
                <div class="panel-body">
                <div class="row">
                    <div class="col-lg-12"> 
                    <!--- Today  START --->
                    <style>
 .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td
 {
	 padding: 5px !important;
 }
 </style>
                    <?php
					
					error_reporting(0);
					
					/// TODAY
					
					$today=$_GET['date'];
					$dayt1=$_GET['tspo'];					
				
				 $regth=$_GET['trt'];
				 $septh=$_GET['tst'];
				
					$dayt2=$_GET['ent'];				
					$dayt3=$_GET['tdt'];				
					$dayt4=$_GET['tvolun'];
					
					/// ONE WEEK
					
				 $oneweek1=$_GET['date1'];
				 $oneweek2=$_GET['date2'];
				 				
     			  $dayoneweek1=$_GET['owspo'];
				 
	     		 $regthoneweek=$_GET['owrt'];
				 $septhoneweek=$_GET['owst'];
				 
				 $dayoneweek2=$_GET['owent'];
				 $dayoneweek3=$_GET['owdt'];
				 $dayoneweek4=$_GET['owvolun'];
				 
				 /// ONE Month
				 
				  $onemonth1=$_GET['date1m'];
				  $onemonth2=$_GET['date2m'];	
				  
				  $dayonemonth1=$_GET['omspo'];
				 
				   $regthoneweek=$_GET['omrt'];
				   $septhoneweek=$_GET['omst'];
							
				  $dayonemonth2=$_GET['oment'];
				  $dayonemonth3=$_GET['omdt'];
				  $dayonemonth4=$_GET['omvolun'];
				
				/// FROM TO 
				 
				   $dob=$_GET['fromdate'];
				   $todate=$_GET['todate'];	
				   
				   $dayfrto1=$_GET['frtospo'];
				   
				   $regthfrto=$_GET['frtort'];
				   $septhfrto=$_GET['frtost'];
				 			
				   $dayfrto2=$_GET['frtoent'];
				   $dayfrto3=$_GET['frtodt'];
				   $dayfrto4=$_GET['frtovolun'];
				   
					?>
                    <!--- Today query START ---> 
                    <!--- Today query SPONSOR (sign up) START --->
                    <?php
                     if($dayt1 == 'tspo')
{
     $date_today = date('Y-m-d');	 
	//echo "select * from mp_regions where date(created_on)='$date_today' AND status='1'";
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Sponsor Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="select * from mp_regions where date(created_on)='$date_today' AND status='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Sponsor Name</th>
                            <th>Sponsor URL</th>
                            <th>Drawing Id</th>
                            <th>Drawing Title</th>
                            <th>Theme Name</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>--> 
                            <!-- <th>Create Date</th>-->
                            <th>Pixel Sponsored</th>
                            <th>Sposored Date</th>
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'url');?></td>
                            <td><?php 
							$di=mysql_result($result, $i, 'user_id');
							  $result44 = mysql_query("SELECT * FROM mp_drawings WHERE user_id ='$di'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $drawingid = $row44['id']; 
							?></td>
                            <td><?php //echo mysql_result($result, $i, 'drawingtitle');							 
	echo  $drawingtitle = $row44['title']; 
	$themeid= $row44['theme_id'];
	
	}
							 ?></td>
                            <td><?php 							
							  $result55 = mysql_query("SELECT * FROM mp_themes WHERE id ='$themeid'");
while ($row55 = mysql_fetch_array($result55)) 
{
	echo  $themename = $row55['name']; 						
	
	}
							 ?></td>
                            
                            <!--<td><?php 
							//$cn=mysql_result($result, $i, 'category_id');
//							  $result44 = mysql_query("SELECT * FROM mp_theme_categories WHERE id ='$cn'");
//while ($row44 = mysql_fetch_array($result44)) 
//{
//	echo  $categoryname = $row44['name']; 
//}	
?></td>--> 
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'created_at');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'x');?></td>
                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "report.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- Today query SPONSOR (sign up)  ENTRANTS END ---> 
                    <!--- Today query Regelar Theme START --->
                    <?php
                     if($regth == 'trt')
{
     $date_today = date('Y-m-d');	 
	//echo "select * from mp_themes AS a ,mp_theme_categories as b where date(created_at)='$date_today' AND a.category_id = b.id AND type='2'";
	//echo "select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on='$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='2'";
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Sponsor Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
//$sql="select * from mp_themes AS a ,mp_theme_categories as b where date(created_at)='$date_today' AND a.category_id = b.id AND type='2'";
$sql="select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on='$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='2'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Sponsor Name</th>
                            <th>Sponsor URL</th>
                            <th>Drawing Id</th>
                            <th>Drawing Title</th>
                            <th>Theme Name</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th>Pixel  Sponsored</th>
                            <th>Sponsored Date</th>
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'url');?></td>
                            <td><?php 
							$di=mysql_result($result, $i, 'user_id');
							  $result44 = mysql_query("SELECT * FROM mp_drawings WHERE user_id ='$di'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $drawingid = $row44['id']; 
							?></td>
                            <td><?php //echo mysql_result($result, $i, 'drawingtitle');							 
	echo  $drawingtitle = $row44['title']; 
	$themeid= $row44['theme_id'];
	
	}
							 ?></td>
                            <td><?php 							
							  $result55 = mysql_query("SELECT * FROM mp_themes WHERE id ='$themeid'");
while ($row55 = mysql_fetch_array($result55)) 
{
	echo  $themename = $row55['name']; 						
	
	}
							 ?></td>
                            
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'x');?></td>
                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- Today query  Regelar Theme END ---> 
                    <!--- Today query Special Theme START --->
                    <?php
                     if($septh == 'tst')
{
     $date_today = date('Y-m-d');	 
	//echo "select * from mp_themes AS a ,mp_theme_categories as b where date(created_at)='$date_today' AND a.category_id = b.id AND type='1'";	
	
	//echo "select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on='$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='1'";
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Sponsor Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on='$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND status='1' AND c.status='1' AND  d.type='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Sponsor Name</th>
                            <th>Sponsor URL</th>
                            <th>Sponsor Date</th>
                            <th>Spl Theme Name</th>
                            <th>Spl Theme Description</th>
                            <th>Spl Theme Price</th>
                            <th>Pixel Sponosored</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>--> 
                            <!--<th>Create Date</th>--> 
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'url');?></td>
                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>
                            <td><?php $di=mysql_result($result, $i, 'user_id');
							  $result777 = mysql_query("SELECT * FROM mp_drawings WHERE user_id ='$di'");
while ($row777 = mysql_fetch_array($result777)) 
{
         $themeid= $row777['theme_id'];						
	}
							 					
							  $result888 = mysql_query("SELECT * FROM mp_themes WHERE id ='$themeid'");
while ($row888 = mysql_fetch_array($result888)) 
{
	echo  $themename = $row888['name']; 		
	      $category_id=$row888['category_id'];	
							 ?></td>
                            <td><?php //echo mysql_result($result, $i, 'drawingtitle');							 
	echo $themedescription= $row888['description'];	
                           	}
							 ?></td>
                            <td><?php 
							//$cn=mysql_result($result, $i, 'category_id');
							  $result44 = mysql_query("SELECT * FROM mp_theme_categories WHERE id ='$category_id'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $themeprice = $row44['amount']; 
}	
?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'x');?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- Today query  Special Theme END ---> 
                    <!--- Today query ENTRANTS START --->
                    <?php
                     if($dayt2 =='ent')
{
     $date_today = date('Y-m-d');	 
	//echo "select * from mp_users where date(created_at)='$date_today' AND is_confirmed='1'";
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Entrants Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="select * from mp_users where date(created_at)='$date_today' AND is_confirmed='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th >Id</th>
                            <th >Email Id</th>
                            <th >First Name</th>
                            <th >Last Name</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th >Create Date</th>
                            <th >Entrants Country</th>
                            <th >Entrants State</th>
                            <th>Entrants City</th>
                            <th>No of drawings submitted</th>
                            <th>Number of sponsors</th>
                            <th>Sponsor_amt</th>
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo $id=mysql_result($result, $i, 'id');?></td>
                            <td><?php echo mysql_result($result, $i, 'email');?></td>
                            <td><?php echo mysql_result($result, $i, 'first_name');?></td>
                            <td><?php echo mysql_result($result, $i, 'last_name');?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>
                            <td><?php 
							$cot=mysql_result($result, $i, 'country');
							  $result44 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $countryname = $row44['name']; 
}	
?></td>
                            <td><?php 
							$st=mysql_result($result, $i, 'state');
							  $result444 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");
while ($row444 = mysql_fetch_array($result444)) 
{
	echo  $statename = $row444['name']; 
}	
?></td>
                            <td><?php 
							$ct=mysql_result($result, $i, 'city');
							  $result4444 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");
while ($row4444 = mysql_fetch_array($result4444)) 
{
	echo  $cityname = $row4444['name']; 
}	
?></td>
                            <td><?php   //echo "select COUNT(user_id) from mp_drawings where user_id='$id'";
 $result2 = mysql_query("select COUNT(user_id) from mp_drawings where user_id='$id'"); 
				$row2 = mysql_fetch_array($result2);
 echo $total2 = $row2[0];
 ?></td>
                            <td><?php   //echo "select COUNT(user_id) from mp_payments where user_id='$id'";
 $result21 = mysql_query("select COUNT(user_id) from mp_payments where user_id='$id'"); 
				$row21 = mysql_fetch_array($result21);
 echo $total21 = $row21[0];
 ?></td>
                            <td><?php   //echo "select COUNT(amount) from mp_payments where user_id='$id'";
 $result23 = mysql_query("select COUNT(amount) from mp_payments where user_id='$id'"); 
				$row23 = mysql_fetch_array($result23);
 echo $total23 = $row23[0];
 ?></td>
                            
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- Today query  ENTRANTS END ---> 
                    <!--- Today query Drawings START --->
                    <?php
                     if($dayt3 =='tdt')
{
     $date_today = date('Y-m-d');	 
	//echo "select * from mp_drawings where date(created_at)='$date_today' AND status='1'";
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Drawings Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="select * from mp_drawings where date(created_at)='$date_today' AND status='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Id</th>
                            <th>User Name</th>
                            <th>Theme Name</th>
                            <th>Title</th>
                            <th>Description</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th>Create Date</th>
                            <!--<th>Update Date</th>-->
                            <th>Likes</th>
                            <th>Reports</th>
                            <th>Clicks</th>
                            <th>Volunteer Id</th>
                            <th>Sponsor Amount</th>
                            <th>Sponsor Name</th>
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                             <tr>
                            <td><?php echo mysql_result($result, $i, 'id');?></td>
                            <td><?php  mysql_result($result, $i, 'user_id');
                            $ui=mysql_result($result, $i, 'user_id');
							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");
while ($row77 = mysql_fetch_array($result77)) 
{
	echo $username = $row77['first_name']; 
}	
?></td>
                            <td><?php mysql_result($result, $i, 'id');
                              $ti=mysql_result($result, $i, 'id');
							  $result88 = mysql_query("SELECT * FROM mp_themes WHERE id ='$ti'");
while ($row88 = mysql_fetch_array($result88)) 
{
	echo $themename = $row88['name']; 
}	
?></td>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'description');?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'updated_at');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'likes');?></td>
                            <td><?php echo mysql_result($result, $i, 'reports');?></td>
                            <td><?php echo mysql_result($result, $i, 'clicks');?></td>
                            <td><?php echo mysql_result($result, $i, 'volunteer_id');?></td>
                            <td><?php mysql_result($result, $i, 'id');
                              $di=mysql_result($result, $i, 'id');
							  $result98 = mysql_query("SELECT * FROM mp_payments WHERE drawing_id ='$di'");
while ($row98 = mysql_fetch_array($result98)) 
{
	echo $sponsoramount = $row98['amount']; 
	$regionid= $row98['region_id'];
}	
?></td>
<td><?php //mysql_result($result, $i, 'id');
                              //$ti=mysql_result($result, $i, 'id');
							  $result97 = mysql_query("SELECT * FROM mp_themes WHERE region_id ='$regionid'");
while ($row97 = mysql_fetch_array($result97)) 
{
	echo $sponsorname = $row97['title']; 
}	
?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- Today query  Drawings END ---> 
                    <!--- Today query VOLUNTEER START --->
                    <?php
                     if($dayt4 =='tvolun')
{
     $date_today = date('Y-m-d');	 
	//echo "select * from mp_volunteers where date(created_at)='$date_today' AND status='1'";
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Volunteer Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="select * from mp_volunteers where date(created_at)='$date_today' AND status='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                         <thead>
                            <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>E Mail Id</th>
                            <!--<th>Address</th>-->
                            <th>Phone</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th>Create Date</th>
                            <th >Volunteer Country</th>
                            <th >Volunteer State</th>
                            <th>Volunteer City</th>
                            <th>No of Entrants Introduced</th>
                            <!--<th>Update Date</th>-->
                            <!--<th>Status</th>-->
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'id');?></td>
                            <td><?php echo  mysql_result($result, $i, 'name');
                            //$ui=mysql_result($result, $i, 'user_id');
//							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");
//while ($row77 = mysql_fetch_array($result77)) 
//{
//	 $username = $row77['first_name']; 
//}	
?></td>
                            <td><?php echo mysql_result($result, $i, 'email'); ?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'address');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'phone');?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>
                             <td><?php 
							$cot=mysql_result($result, $i, 'country');
							  $result99 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");
while ($row99 = mysql_fetch_array($result99)) 
{
	echo  $countryname = $row99['name']; 
}	
?></td>
                            <td><?php 
							$st=mysql_result($result, $i, 'state');
							  $result999 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");
while ($row999 = mysql_fetch_array($result999)) 
{
	echo  $statename = $row999['name']; 
}	
?></td>
                            <td><?php 
							$ct=mysql_result($result, $i, 'city');
							  $result9999 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");
while ($row9999 = mysql_fetch_array($result9999)) 
{
	echo  $cityname = $row9999['name']; 
}	
?></td>
<td><?php $entco=mysql_result($result, $i, 'id');
//echo "SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'";
$result9988 = mysql_query("SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'");
				$row9988 = mysql_fetch_array($result9988);
  echo $total9988 = $row9988[0];
?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'updated_at');?></td>-->
                            <!--<td><?php //echo mysql_result($result, $i, 'status');?></td>-->
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- Today query  VOLUNTEER END ---> 
                    <!--- Today query END ---> 
                    <!--- ONe WEEk  query START ---> 
                    <!--- ONe WEEk  query Sponsor (sign up) START --->
                    <?php
                    if($dayoneweek1 == 'owspo')
{
     $date_today = date('Y-m-d');
	 $date_oneweek = strtotime("-1 week"); 
 $date_oneweek = date('Y-m-d', $date_oneweek);	
	//echo "SELECT * FROM mp_regions WHERE date(created_on) >= '$date_oneweek' AND (created_on) <= '$date_today' AND status='1'"	
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Sponsor Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="SELECT * FROM mp_regions WHERE date(created_on) >= '$date_oneweek' AND (created_on) <= '$date_today' AND status='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Sponsor Name</th>
                            <th>Sponsor URL</th>
                            <th>Drawing Id</th>
                            <th>Drawing Title</th>
                            <th>Theme Name</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>--> 
                            <!-- <th>Create Date</th>-->
                            <th>Pixel Sponsored</th>
                            <th>Sposored Date</th>
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'url');?></td>
                            <td><?php 
							$di=mysql_result($result, $i, 'user_id');
							  $result44 = mysql_query("SELECT * FROM mp_drawings WHERE user_id ='$di'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $drawingid = $row44['id']; 
							?></td>
                            <td><?php //echo mysql_result($result, $i, 'drawingtitle');							 
	echo  $drawingtitle = $row44['title']; 
	$themeid= $row44['theme_id'];
	
	}
							 ?></td>
                            <td><?php 							
							  $result55 = mysql_query("SELECT * FROM mp_themes WHERE id ='$themeid'");
while ($row55 = mysql_fetch_array($result55)) 
{
	echo  $themename = $row55['name']; 						
	
	}
							 ?></td>
                            
                            <!--<td><?php 
							//$cn=mysql_result($result, $i, 'category_id');
//							  $result44 = mysql_query("SELECT * FROM mp_theme_categories WHERE id ='$cn'");
//while ($row44 = mysql_fetch_array($result44)) 
//{
//	echo  $categoryname = $row44['name']; 
//}	
?></td>--> 
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'created_at');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'x');?></td>
                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- ONe WEEk  query Sponsor (sign up) END ---> 
                    <!--- ONe WEEk  query Regular theme START --->
                    <?php
					$regthoneweek=$_GET['owrt'];
                    if($regthoneweek =='owrt')
					{
     $date_today = date('Y-m-d');
	 $date_oneweek = strtotime("-1 week"); 
 $date_oneweek = date('Y-m-d', $date_oneweek);	
	//echo "select * from mp_themes AS a ,mp_theme_categories as b where  date(created_at) >= '$date_oneweek' AND (created_at) <= '$date_today' AND a.category_id = b.id AND type='2'"	
	//echo "select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$date_oneweek' AND a.created_on <= '$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='2'";
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Sponsor Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$date_oneweek' AND a.created_on <= '$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='2'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Sponsor Name</th>
                            <th>Sponsor URL</th>
                            <th>Drawing Id</th>
                            <th>Drawing Title</th>
                            <th>Theme Name</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th>Pixel  Sponsored</th>
                            <th>Sponsored Date</th>
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'url');?></td>
                            <td><?php 
							$di=mysql_result($result, $i, 'user_id');
							  $result44 = mysql_query("SELECT * FROM mp_drawings WHERE user_id ='$di'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $drawingid = $row44['id']; 
							?></td>
                            <td><?php //echo mysql_result($result, $i, 'drawingtitle');							 
	echo  $drawingtitle = $row44['title']; 
	$themeid= $row44['theme_id'];
	
	}
							 ?></td>
                            <td><?php 							
							  $result55 = mysql_query("SELECT * FROM mp_themes WHERE id ='$themeid'");
while ($row55 = mysql_fetch_array($result55)) 
{
	echo  $themename = $row55['name']; 						
	
	}
							 ?></td>
                            
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'x');?></td>
                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- ONe WEEk  query Regular theme END ---> 
                    <!--- ONe WEEk  query Special theme START --->
                    <?php
				 $septhoneweek=$_GET['owst'];
                    if($septhoneweek == 'owst')
{
     $date_today = date('Y-m-d');
	 $date_oneweek = strtotime("-1 week"); 
 $date_oneweek = date('Y-m-d', $date_oneweek);	 
//echo "select * from mp_themes AS a ,mp_theme_categories as b where  date(created_at) >= '$date_oneweek' AND (created_at) <= '$date_today' AND a.category_id = b.id AND type='1'";

//echo "select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$date_oneweek' AND a.created_on <= '$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='1'";
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Sponsor Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$date_oneweek' AND a.created_on <= '$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Sponsor Name</th>
                            <th>Sponsor URL</th>
                            <th>Sponsor Date</th>
                            <th>Spl Theme Name</th>
                            <th>Spl Theme Description</th>
                            <th>Spl Theme Price</th>
                            <th>Pixel Sponosored</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>--> 
                            <!--<th>Create Date</th>--> 
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'url');?></td>
                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>
                            <td><?php $di=mysql_result($result, $i, 'user_id');
							  $result777 = mysql_query("SELECT * FROM mp_drawings WHERE user_id ='$di'");
while ($row777 = mysql_fetch_array($result777)) 
{
         $themeid= $row777['theme_id'];						
	}
							 					
							  $result888 = mysql_query("SELECT * FROM mp_themes WHERE id ='$themeid'");
while ($row888 = mysql_fetch_array($result888)) 
{
	echo  $themename = $row888['name']; 		
	      $category_id=$row888['category_id'];	
							 ?></td>
                            <td><?php //echo mysql_result($result, $i, 'drawingtitle');							 
	echo $themedescription= $row888['description'];	
                           	}
							 ?></td>
                            <td><?php 
							//$cn=mysql_result($result, $i, 'category_id');
							  $result44 = mysql_query("SELECT * FROM mp_theme_categories WHERE id ='$category_id'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $themeprice = $row44['amount']; 
}	
?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'x');?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- ONe WEEk  query Special theme END ---> 
                    <!--- ONe WEEk  query ENTRANT START --->
                    <?php
                    if($dayoneweek2 == 'owent')
{
     $date_today = date('Y-m-d');
	 $date_oneweek = strtotime("-1 week"); 
 $date_oneweek = date('Y-m-d', $date_oneweek);	 
	// echo "SELECT * FROM mp_users WHERE date(created_at) >= '$date_oneweek' AND (created_at) <= '$date_today'";	
	//echo "SELECT * FROM mp_users WHERE date(created_at) >= '$date_oneweek' AND (created_at) <= '$date_today' AND is_confirmed='1'"	
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Entrants Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="SELECT * FROM mp_users WHERE date(created_at) >= '$date_oneweek' AND (created_at) <= '$date_today' AND is_confirmed='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th >Id</th>
                            <th >Email Id</th>
                            <th >First Name</th>
                            <th >Last Name</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th >Create Date</th>
                            <th >Entrants Country</th>
                            <th >Entrants State</th>
                            <th>Entrants City</th>
                            <th>No of drawings submitted</th>
                            <th>Number of sponsors</th>
                            <th>Sponsor_amt</th>
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo $id=mysql_result($result, $i, 'id');?></td>
                            <td><?php echo mysql_result($result, $i, 'email');?></td>
                            <td><?php echo mysql_result($result, $i, 'first_name');?></td>
                            <td><?php echo mysql_result($result, $i, 'last_name');?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>
                            <td><?php 
							$cot=mysql_result($result, $i, 'country');
							  $result44 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $countryname = $row44['name']; 
}	
?></td>
                            <td><?php 
							$st=mysql_result($result, $i, 'state');
							  $result444 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");
while ($row444 = mysql_fetch_array($result444)) 
{
	echo  $statename = $row444['name']; 
}	
?></td>
                            <td><?php 
							$ct=mysql_result($result, $i, 'city');
							  $result4444 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");
while ($row4444 = mysql_fetch_array($result4444)) 
{
	echo  $cityname = $row4444['name']; 
}	
?></td>
                            <td><?php   //echo "select COUNT(user_id) from mp_drawings where user_id='$id'";
 $result2 = mysql_query("select COUNT(user_id) from mp_drawings where user_id='$id'"); 
				$row2 = mysql_fetch_array($result2);
 echo $total2 = $row2[0];
 ?></td>
                            <td><?php   //echo "select COUNT(user_id) from mp_payments where user_id='$id'";
 $result21 = mysql_query("select COUNT(user_id) from mp_payments where user_id='$id'"); 
				$row21 = mysql_fetch_array($result21);
 echo $total21 = $row21[0];
 ?></td>
                            <td><?php   //echo "select COUNT(amount) from mp_payments where user_id='$id'";
 $result23 = mysql_query("select COUNT(amount) from mp_payments where user_id='$id'"); 
				$row23 = mysql_fetch_array($result23);
 echo $total23 = $row23[0];
 ?></td>
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- One WEEk query ENTRANT  END ---> 
                    <!--- ONe WEEk  query Drawings START --->
                    <?php
                    if($dayoneweek3 == 'owdt') 
{
     $date_today = date('Y-m-d');
	 $date_oneweek = strtotime("-1 week"); 
 $date_oneweek = date('Y-m-d', $date_oneweek);	 
	// echo "SELECT * FROM mp_drawings WHERE date(created_at) >= '$date_oneweek' AND (created_at) <= '$date_today'";	
	//echo "SELECT * FROM mp_drawings WHERE date(created_at) >= '$date_oneweek' AND (created_at) <= '$date_today' AND status='1'"	
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Drawings Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="SELECT * FROM mp_drawings WHERE date(created_at) >= '$date_oneweek' AND (created_at) <= '$date_today' AND status='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Id</th>
                            <th>User Name</th>
                            <th>Theme Name</th>
                            <th>Title</th>
                            <th>Description</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th>Create Date</th>
                            <!--<th>Update Date</th>-->
                            <th>Likes</th>
                            <th>Reports</th>
                            <th>Clicks</th>
                            <th>Volunteer Id</th>
                            <th>Sponsor Amount</th>
                            <th>Sponsor Name</th>
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'id');?></td>
                            <td><?php  mysql_result($result, $i, 'user_id');
                            $ui=mysql_result($result, $i, 'user_id');
							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");
while ($row77 = mysql_fetch_array($result77)) 
{
	echo $username = $row77['first_name']; 
}	
?></td>
                            <td><?php mysql_result($result, $i, 'id');
                              $ti=mysql_result($result, $i, 'id');
							  $result88 = mysql_query("SELECT * FROM mp_themes WHERE id ='$ti'");
while ($row88 = mysql_fetch_array($result88)) 
{
	echo $themename = $row88['name']; 
}	
?></td>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'description');?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'updated_at');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'likes');?></td>
                            <td><?php echo mysql_result($result, $i, 'reports');?></td>
                            <td><?php echo mysql_result($result, $i, 'clicks');?></td>
                            <td><?php echo mysql_result($result, $i, 'volunteer_id');?></td>
                            <td><?php mysql_result($result, $i, 'id');
                              $di=mysql_result($result, $i, 'id');
							  $result98 = mysql_query("SELECT * FROM mp_payments WHERE drawing_id ='$di'");
while ($row98 = mysql_fetch_array($result98)) 
{
	echo $sponsoramount = $row98['amount']; 
	$regionid= $row98['region_id'];
}	
?></td>
<td><?php //mysql_result($result, $i, 'id');
                              //$ti=mysql_result($result, $i, 'id');
							  $result97 = mysql_query("SELECT * FROM mp_themes WHERE region_id ='$regionid'");
while ($row97 = mysql_fetch_array($result97)) 
{
	echo $sponsorname = $row97['title']; 
}	
?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- One WEEk query Drawings  END ---> 
                    <!--- ONe WEEk  query Volunteer START --->
                    <?php
                    if($dayoneweek4 == 'owvolun') 
{
     $date_today = date('Y-m-d');
	 $date_oneweek = strtotime("-1 week"); 
 $date_oneweek = date('Y-m-d', $date_oneweek);	 
	// echo "SELECT * FROM mp_volunteers WHERE date(created_at) >= '$date_oneweek' AND (created_at) <= '$date_today'";	
	//echo "SELECT * FROM mp_volunteers WHERE date(created_at) >= '$date_oneweek' AND (created_at) <= '$date_today' AND status='1'"	
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Volunteer Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="SELECT * FROM mp_volunteers WHERE date(created_at) >= '$date_oneweek' AND (created_at) <= '$date_today' AND status='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                         <thead>
                            <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>E Mail Id</th>
                            <!--<th>Address</th>-->
                            <th>Phone</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th>Create Date</th>
                            <th >Volunteer Country</th>
                            <th >Volunteer State</th>
                            <th>Volunteer City</th>
                            <th>No of Entrants Introduced</th>
                            <!--<th>Update Date</th>-->
                            <!--<th>Status</th>-->
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'id');?></td>
                            <td><?php echo  mysql_result($result, $i, 'name');
                            //$ui=mysql_result($result, $i, 'user_id');
//							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");
//while ($row77 = mysql_fetch_array($result77)) 
//{
//	 $username = $row77['first_name']; 
//}	
?></td>
                            <td><?php echo mysql_result($result, $i, 'email'); ?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'address');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'phone');?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>
                             <td><?php 
							$cot=mysql_result($result, $i, 'country');
							  $result99 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");
while ($row99 = mysql_fetch_array($result99)) 
{
	echo  $countryname = $row99['name']; 
}	
?></td>
                            <td><?php 
							$st=mysql_result($result, $i, 'state');
							  $result999 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");
while ($row999 = mysql_fetch_array($result999)) 
{
	echo  $statename = $row999['name']; 
}	
?></td>
                            <td><?php 
							$ct=mysql_result($result, $i, 'city');
							  $result9999 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");
while ($row9999 = mysql_fetch_array($result9999)) 
{
	echo  $cityname = $row9999['name']; 
}	
?></td>
<td><?php $entco=mysql_result($result, $i, 'id');
//echo "SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'";
$result9988 = mysql_query("SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'");
				$row9988 = mysql_fetch_array($result9988);
  echo $total9988 = $row9988[0];
?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'updated_at');?></td>-->
                            <!--<td><?php //echo mysql_result($result, $i, 'status');?></td>-->
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- One WEEk query Volunteer  END ---> 
                    <!--- One WEEk query END ---> 
                    <!--- ONE MONTH query  START ---> 
                    <!--- ONE MONTH query Sponsor Sign up  START --->
                    <?php
                     if($dayonemonth1 == 'omspo')
{
     $date_today = date('Y-m-d');
 $date_onemonth = strtotime("-1 month");
 $date_onemonth = date('Y-m-d', $date_onemonth); 
 	//echo "SELECT * FROM mp_regions WHERE date(created_on) >= '$date_onemonth' AND (created_on) <= '$date_today' AND status='1'";	
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Sponsor Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="SELECT * FROM mp_regions WHERE date(created_on) >= '$date_onemonth' AND (created_on) <= '$date_today' AND status='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Sponsor Name</th>
                            <th>Sponsor URL</th>
                            <th>Drawing Id</th>
                            <th>Drawing Title</th>
                            <th>Theme Name</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>--> 
                            <!-- <th>Create Date</th>-->
                            <th>Pixel Sponsored</th>
                            <th>Sposored Date</th>
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'url');?></td>
                            <td><?php 
							$di=mysql_result($result, $i, 'user_id');
							  $result44 = mysql_query("SELECT * FROM mp_drawings WHERE user_id ='$di'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $drawingid = $row44['id']; 
							?></td>
                            <td><?php //echo mysql_result($result, $i, 'drawingtitle');							 
	echo  $drawingtitle = $row44['title']; 
	$themeid= $row44['theme_id'];
	
	}
							 ?></td>
                            <td><?php 							
							  $result55 = mysql_query("SELECT * FROM mp_themes WHERE id ='$themeid'");
while ($row55 = mysql_fetch_array($result55)) 
{
	echo  $themename = $row55['name']; 						
	
	}
							 ?></td>
                            
                            <!--<td><?php 
							//$cn=mysql_result($result, $i, 'category_id');
//							  $result44 = mysql_query("SELECT * FROM mp_theme_categories WHERE id ='$cn'");
//while ($row44 = mysql_fetch_array($result44)) 
//{
//	echo  $categoryname = $row44['name']; 
//}	
?></td>--> 
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'created_at');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'x');?></td>
                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- ONE MONTH query Sponsor Sign up  END ---> 
                    <!--- ONE MONTH query Regular  START --->
                    <?php
					 $regthoneweek=$_GET['omrt'];
                     if($regthoneweek == 'omrt')
{
     $date_today = date('Y-m-d');
 $date_onemonth = strtotime("-1 month");
 $date_onemonth = date('Y-m-d', $date_onemonth); 
 	//echo "select * from mp_themes AS a ,mp_theme_categories as b where  date(created_at) = '$date_onemonth' AND (created_at) = '$date_today' AND a.category_id = b.id AND type='2'";	
	
	//echo "select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$date_onemonth' AND a.created_on <= '$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='2'";
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Sponsor Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$date_onemonth' AND a.created_on <= '$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='2'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Sponsor Name</th>
                            <th>Sponsor URL</th>
                            <th>Drawing Id</th>
                            <th>Drawing Title</th>
                            <th>Theme Name</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th>Pixel  Sponsored</th>
                            <th>Sponsored Date</th>
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'url');?></td>
                            <td><?php 
							$di=mysql_result($result, $i, 'user_id');
							  $result44 = mysql_query("SELECT * FROM mp_drawings WHERE user_id ='$di'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $drawingid = $row44['id']; 
							?></td>
                            <td><?php //echo mysql_result($result, $i, 'drawingtitle');							 
	echo  $drawingtitle = $row44['title']; 
	$themeid= $row44['theme_id'];
	
	}
							 ?></td>
                            <td><?php 							
							  $result55 = mysql_query("SELECT * FROM mp_themes WHERE id ='$themeid'");
while ($row55 = mysql_fetch_array($result55)) 
{
	echo  $themename = $row55['name']; 						
	
	}
							 ?></td>
                            
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'x');?></td>
                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- ONE MONTH query Regular  END ---> 
                    <!--- ONE MONTH query Special START --->
                    <?php
				   $septhoneweek=$_GET['omst'];
                     if($septhoneweek == 'omst')
{
     $date_today = date('Y-m-d');
 $date_onemonth = strtotime("-1 month");
 $date_onemonth = date('Y-m-d', $date_onemonth); 
 	//echo "select * from mp_themes AS a ,mp_theme_categories as b where date(created_at) >= '$date_onemonth' AND (created_at) <= '$date_today' AND a.category_id = b.id AND type='1'";	
	
	//echo "select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$date_onemonth' AND a.created_on <= '$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='1'";
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Sponsor Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$date_onemonth' AND a.created_on <= '$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Sponsor Name</th>
                            <th>Sponsor URL</th>
                            <th>Sponsor Date</th>
                            <th>Spl Theme Name</th>
                            <th>Spl Theme Description</th>
                            <th>Spl Theme Price</th>
                            <th>Pixel Sponosored</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>--> 
                            <!--<th>Create Date</th>--> 
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'url');?></td>
                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>
                            <td><?php $di=mysql_result($result, $i, 'user_id');
							  $result777 = mysql_query("SELECT * FROM mp_drawings WHERE user_id ='$di'");
while ($row777 = mysql_fetch_array($result777)) 
{
         $themeid= $row777['theme_id'];						
	}
							 					
							  $result888 = mysql_query("SELECT * FROM mp_themes WHERE id ='$themeid'");
while ($row888 = mysql_fetch_array($result888)) 
{
	echo  $themename = $row888['name']; 		
	      $category_id=$row888['category_id'];	
							 ?></td>
                            <td><?php //echo mysql_result($result, $i, 'drawingtitle');							 
	echo $themedescription= $row888['description'];	
                           	}
							 ?></td>
                            <td><?php 
							//$cn=mysql_result($result, $i, 'category_id');
							  $result44 = mysql_query("SELECT * FROM mp_theme_categories WHERE id ='$category_id'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $themeprice = $row44['amount']; 
}	
?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'x');?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- ONE MONTH query Special  END ---> 
                    <!--- ONE MONTH query Entrant  START --->
                    <?php
                     if($dayonemonth2 =='oment')
{
     $date_today = date('Y-m-d');
 $date_onemonth = strtotime("-1 month");
 $date_onemonth = date('Y-m-d', $date_onemonth); 
 	//echo "SELECT * FROM mp_users WHERE date(created_at) >= '$date_onemonth' AND (created_at) <= '$date_today' AND is_confirmed ='1'";	
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Entrants Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="SELECT * FROM mp_users WHERE date(created_at) >= '$date_onemonth' AND (created_at) <= '$date_today' AND is_confirmed='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th >Id</th>
                            <th >Email Id</th>
                            <th >First Name</th>
                            <th >Last Name</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th >Create Date</th>
                            <th >Entrants Country</th>
                            <th >Entrants State</th>
                            <th>Entrants City</th>
                            <th>No of drawings submitted</th>
                            <th>Number of sponsors</th>
                            <th>Sponsor_amt</th>
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo $id=mysql_result($result, $i, 'id');?></td>
                            <td><?php echo mysql_result($result, $i, 'email');?></td>
                            <td><?php echo mysql_result($result, $i, 'first_name');?></td>
                            <td><?php echo mysql_result($result, $i, 'last_name');?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>
                            <td><?php 
							$cot=mysql_result($result, $i, 'country');
							  $result44 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $countryname = $row44['name']; 
}	
?></td>
                            <td><?php 
							$st=mysql_result($result, $i, 'state');
							  $result444 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");
while ($row444 = mysql_fetch_array($result444)) 
{
	echo  $statename = $row444['name']; 
}	
?></td>
                            <td><?php 
							$ct=mysql_result($result, $i, 'city');
							  $result4444 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");
while ($row4444 = mysql_fetch_array($result4444)) 
{
	echo  $cityname = $row4444['name']; 
}	
?></td>
                            <td><?php   //echo "select COUNT(user_id) from mp_drawings where user_id='$id'";
 $result2 = mysql_query("select COUNT(user_id) from mp_drawings where user_id='$id'"); 
				$row2 = mysql_fetch_array($result2);
 echo $total2 = $row2[0];
 ?></td>
                            <td><?php   //echo "select COUNT(user_id) from mp_payments where user_id='$id'";
 $result21 = mysql_query("select COUNT(user_id) from mp_payments where user_id='$id'"); 
				$row21 = mysql_fetch_array($result21);
 echo $total21 = $row21[0];
 ?></td>
                            <td><?php   //echo "select COUNT(amount) from mp_payments where user_id='$id'";
 $result23 = mysql_query("select COUNT(amount) from mp_payments where user_id='$id'"); 
				$row23 = mysql_fetch_array($result23);
 echo $total23 = $row23[0];
 ?></td>
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- ONE MONTH query Entrant  END ---> 
                    <!--- ONE MONTH query Drawings START --->
                    <?php
                     if($dayonemonth3 == 'omdt')
{
     $date_today = date('Y-m-d');
 $date_onemonth = strtotime("-1 month");
 $date_onemonth = date('Y-m-d', $date_onemonth); 
 	//echo "SELECT * FROM mp_drawings WHERE date(created_at) >= '$date_onemonth' AND (created_at) <= '$date_today' AND status='1'";	
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Drawings Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="SELECT * FROM mp_drawings WHERE date(created_at) >= '$date_onemonth' AND (created_at) <= '$date_today' AND status='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Id</th>
                            <th>User Name</th>
                            <th>Theme Name</th>
                            <th>Title</th>
                            <th>Description</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th>Create Date</th>
                            <!--<th>Update Date</th>-->
                            <th>Likes</th>
                            <th>Reports</th>
                            <th>Clicks</th>
                            <th>Volunteer Id</th>
                            <th>Sponsor Amount</th>
                            <th>Sponsor Name</th>
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'id');?></td>
                            <td><?php  mysql_result($result, $i, 'user_id');
                            $ui=mysql_result($result, $i, 'user_id');
							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");
while ($row77 = mysql_fetch_array($result77)) 
{
	echo $username = $row77['first_name']; 
}	
?></td>
                            <td><?php mysql_result($result, $i, 'id');
                              $ti=mysql_result($result, $i, 'id');
							  $result88 = mysql_query("SELECT * FROM mp_themes WHERE id ='$ti'");
while ($row88 = mysql_fetch_array($result88)) 
{
	echo $themename = $row88['name']; 
}	
?></td>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'description');?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'updated_at');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'likes');?></td>
                            <td><?php echo mysql_result($result, $i, 'reports');?></td>
                            <td><?php echo mysql_result($result, $i, 'clicks');?></td>
                            <td><?php echo mysql_result($result, $i, 'volunteer_id');?></td>
                            <td><?php mysql_result($result, $i, 'id');
                              $di=mysql_result($result, $i, 'id');
							  $result98 = mysql_query("SELECT * FROM mp_payments WHERE drawing_id ='$di'");
while ($row98 = mysql_fetch_array($result98)) 
{
	echo $sponsoramount = $row98['amount']; 
	$regionid= $row98['region_id'];
}	
?></td>
<td><?php //mysql_result($result, $i, 'id');
                              //$ti=mysql_result($result, $i, 'id');
							  $result97 = mysql_query("SELECT * FROM mp_themes WHERE region_id ='$regionid'");
while ($row97 = mysql_fetch_array($result97)) 
{
	echo $sponsorname = $row97['title']; 
}	
?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- ONE MONTH query Drawings End ---> 
                    <!--- ONE MONTH query VOLUNTEER START --->
                    <?php
                     if($dayonemonth4 == 'omvolun')
{
     $date_today = date('Y-m-d');
 $date_onemonth = strtotime("-1 month");
 $date_onemonth = date('Y-m-d', $date_onemonth); 
 	//echo "SELECT * FROM mp_volunteers WHERE date(created_at) >= '$date_onemonth' AND (created_at) <= '$date_today' AND status='1'";	
	 ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Volunteer Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
$sql="SELECT * FROM mp_volunteers WHERE date(created_at) >= '$date_onemonth' AND (created_at) <= '$date_today' AND status='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>E Mail Id</th>
                            <!--<th>Address</th>-->
                            <th>Phone</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th>Create Date</th>
                            <th >Volunteer Country</th>
                            <th >Volunteer State</th>
                            <th>Volunteer City</th>
                            <th>No of Entrants Introduced</th>
                            <!--<th>Update Date</th>-->
                            <!--<th>Status</th>-->
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'id');?></td>
                            <td><?php echo  mysql_result($result, $i, 'name');
                            //$ui=mysql_result($result, $i, 'user_id');
//							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");
//while ($row77 = mysql_fetch_array($result77)) 
//{
//	 $username = $row77['first_name']; 
//}	
?></td>
                            <td><?php echo mysql_result($result, $i, 'email'); ?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'address');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'phone');?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>
                             <td><?php 
							$cot=mysql_result($result, $i, 'country');
							  $result99 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");
while ($row99 = mysql_fetch_array($result99)) 
{
	echo  $countryname = $row99['name']; 
}	
?></td>
                            <td><?php 
							$st=mysql_result($result, $i, 'state');
							  $result999 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");
while ($row999 = mysql_fetch_array($result999)) 
{
	echo  $statename = $row999['name']; 
}	
?></td>
                            <td><?php 
							$ct=mysql_result($result, $i, 'city');
							  $result9999 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");
while ($row9999 = mysql_fetch_array($result9999)) 
{
	echo  $cityname = $row9999['name']; 
}	
?></td>
<td><?php $entco=mysql_result($result, $i, 'id');
//echo "SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'";
$result9988 = mysql_query("SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'");
				$row9988 = mysql_fetch_array($result9988);
  echo $total9988 = $row9988[0];
?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'updated_at');?></td>-->
                            <!--<td><?php //echo mysql_result($result, $i, 'status');?></td>-->
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";		
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- ONE MONTH query VOLUNTEER END ---> 
                    <!--- One MONTH query  END ---> 
                    <!--- From TO query START ---> 
                    <!--- From TO query Sponsor Sign up START --->
                    <?php
					$dob=$_GET['fromdate'];
				   $todate=$_GET['todate'];						
                     if ($dayfrto1 == 'frtospo')
{	
//$dob = mysql_real_escape_string($_POST['dob']);
//$todate = mysql_real_escape_string($_POST['todate']);
//save data
error_reporting(0);
 //$query1="insert into user(user_email_id,user_status,user_type,user_password,created_date_time,last_updated_date_time,last_login_date_time,user_reset_pwd_status) values('$user_email_id','$user_status','$user_type','$user_password','$created_date_time','$last_updated_date_time','$last_login_date_time','$user_reset_pwd_status')";  
 $php_timestamp = time();
// echo "SELECT * FROM mp_regions WHERE date(created_on) >= '$dob' AND (created_on) <= '$todate' AND status='1'";
                  ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Sponsor Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
 $sql="SELECT * FROM mp_regions WHERE date(created_on) >= '$dob' AND (created_on) <= '$todate' AND status='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Sponsor Name</th>
                            <th>Sponsor URL</th>
                            <th>Drawing Id</th>
                            <th>Drawing Title</th>
                            <th>Theme Name</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>--> 
                            <!-- <th>Create Date</th>-->
                            <th>Pixel Sponsored</th>
                            <th>Sposored Date</th>
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'url');?></td>
                            <td><?php 
							$di=mysql_result($result, $i, 'user_id');
							  $result44 = mysql_query("SELECT * FROM mp_drawings WHERE user_id ='$di'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $drawingid = $row44['id']; 
							?></td>
                            <td><?php //echo mysql_result($result, $i, 'drawingtitle');							 
	echo  $drawingtitle = $row44['title']; 
	$themeid= $row44['theme_id'];
	}
							 ?></td>
                            <td><?php 							
							  $result55 = mysql_query("SELECT * FROM mp_themes WHERE id ='$themeid'");
while ($row55 = mysql_fetch_array($result55)) 
{
	echo  $themename = $row55['name']; 	
	}
							 ?></td>                            
                            <!--<td><?php 
							//$cn=mysql_result($result, $i, 'category_id');
//							  $result44 = mysql_query("SELECT * FROM mp_theme_categories WHERE id ='$cn'");
//while ($row44 = mysql_fetch_array($result44)) 
//{
//	echo  $categoryname = $row44['name']; 
//}	
?></td>--> 
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'created_at');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'x');?></td>
                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";	
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- From TO query SPONSOR signup END ---> 
                    <!--- From TO query Regular START --->
                    <?php
					$dob=$_GET['fromdate'];
				   $todate=$_GET['todate'];		
				    $regthfrto=$_GET['frtort'];		
                     if ($regthfrto == 'frtort')
{	
//$dob = mysql_real_escape_string($_POST['dob']);
//$todate = mysql_real_escape_string($_POST['todate']);
//save data
error_reporting(0);
 //$query1="insert into user(user_email_id,user_status,user_type,user_password,created_date_time,last_updated_date_time,last_login_date_time,user_reset_pwd_status) values('$user_email_id','$user_status','$user_type','$user_password','$created_date_time','$last_updated_date_time','$last_login_date_time','$user_reset_pwd_status')";  
 $php_timestamp = time();
 //echo "select * from mp_themes AS a ,mp_theme_categories as b where  date(created_at) >= '$dob' AND (created_at) <= '$todate' AND a.category_id = b.id AND type='2'";
 
 //echo "select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$dob' AND a.created_on <= '$todate' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND  d.type='2'";
                  ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Sponsor Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
 $sql="select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$dob' AND a.created_on <= '$todate' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND c.status='1' AND  d.type='2'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Sponsor Name</th>
                            <th>Sponsor URL</th>
                            <th>Drawing Id</th>
                            <th>Drawing Title</th>
                            <th>Theme Name</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th>Pixel  Sponsored</th>
                            <th>Sponsored Date</th>
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'url');?></td>
                            <td><?php 
							$di=mysql_result($result, $i, 'user_id');
							  $result44 = mysql_query("SELECT * FROM mp_drawings WHERE user_id ='$di'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $drawingid = $row44['id']; 
							?></td>
                            <td><?php //echo mysql_result($result, $i, 'drawingtitle');							 
	echo  $drawingtitle = $row44['title']; 
	$themeid= $row44['theme_id'];
	
	}
							 ?></td>
                            <td><?php 							
							  $result55 = mysql_query("SELECT * FROM mp_themes WHERE id ='$themeid'");
while ($row55 = mysql_fetch_array($result55)) 
{
	echo  $themename = $row55['name']; 						
	
	}
							 ?></td>
                            
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'x');?></td>
                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";	
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- From TO query Regular END ---> 
                    <!--- From TO query Special START --->
                    <?php
					$dob=$_GET['fromdate'];
				   $todate=$_GET['todate'];	
				    $septhfrto=$_GET['frtost'];				
                     if ($septhfrto == 'frtost')
{	
//$dob = mysql_real_escape_string($_POST['dob']);
//$todate = mysql_real_escape_string($_POST['todate']);
//save data
error_reporting(0);
 //$query1="insert into user(user_email_id,user_status,user_type,user_password,created_date_time,last_updated_date_time,last_login_date_time,user_reset_pwd_status) values('$user_email_id','$user_status','$user_type','$user_password','$created_date_time','$last_updated_date_time','$last_login_date_time','$user_reset_pwd_status')";  
 $php_timestamp = time();
 //echo "select * from mp_themes AS a ,mp_theme_categories as b where date(created_at) >= '$dob' AND (created_at) <= '$todate' AND a.category_id = b.id AND type='1'";
 
 //echo "select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$dob' AND a.created_on <= '$todate' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='1'";
                  ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Sponsor Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
 $sql="select * from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$dob' AND a.created_on <= '$todate' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Sponsor Name</th>
                            <th>Sponsor URL</th>
                            <th>Sponsor Date</th>
                            <th>Spl Theme Name</th>
                            <th>Spl Theme Description</th>
                            <th>Spl Theme Price</th>
                            <th>Pixel Sponosored</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>--> 
                            <!--<th>Create Date</th>--> 
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'url');?></td>
                            <td><?php echo mysql_result($result, $i, 'created_on');?></td>
                            <td><?php $di=mysql_result($result, $i, 'user_id');
							  $result777 = mysql_query("SELECT * FROM mp_drawings WHERE user_id ='$di'");
while ($row777 = mysql_fetch_array($result777)) 
{
         $themeid= $row777['theme_id'];						
	}
							 					
							  $result888 = mysql_query("SELECT * FROM mp_themes WHERE id ='$themeid'");
while ($row888 = mysql_fetch_array($result888)) 
{
	echo  $themename = $row888['name']; 		
	      $category_id=$row888['category_id'];	
							 ?></td>
                            <td><?php //echo mysql_result($result, $i, 'drawingtitle');							 
	echo $themedescription= $row888['description'];	
                           	}
							 ?></td>
                            <td><?php 
							//$cn=mysql_result($result, $i, 'category_id');
							  $result44 = mysql_query("SELECT * FROM mp_theme_categories WHERE id ='$category_id'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $themeprice = $row44['amount']; 
}	
?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'x');?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";	
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- From TO query Special END ---> 
                    <!--- From TO query ENTRANT START --->
                    <?php
					$dob=$_GET['fromdate'];
				   $todate=$_GET['todate'];						
                     if ($dayfrto2 == 'frtoent')
{	
//$dob = mysql_real_escape_string($_POST['dob']);
//$todate = mysql_real_escape_string($_POST['todate']);
//save data
error_reporting(0);
 //$query1="insert into user(user_email_id,user_status,user_type,user_password,created_date_time,last_updated_date_time,last_login_date_time,user_reset_pwd_status) values('$user_email_id','$user_status','$user_type','$user_password','$created_date_time','$last_updated_date_time','$last_login_date_time','$user_reset_pwd_status')";  
 $php_timestamp = time();
 //echo "SELECT * FROM mp_users WHERE date(created_at) >= '$dob' AND (created_at) <= '$todate' AND is_confirmed='1'";
                  ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Entrants Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
 $sql="SELECT * FROM mp_users WHERE date(created_at) >= '$dob' AND (created_at) <= '$todate' AND is_confirmed='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th >Id</th>
                            <th >Email Id</th>
                            <th >First Name</th>
                            <th >Last Name</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th >Create Date</th>
                            <th >Entrants Country</th>
                            <th >Entrants State</th>
                            <th>Entrants City</th>
                            <th>No of drawings submitted</th>
                            <th>Number of sponsors</th>
                            <th>Sponsor_amt</th>
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                            <tr>
                            <td><?php echo $id=mysql_result($result, $i, 'id');?></td>
                            <td><?php echo mysql_result($result, $i, 'email');?></td>
                            <td><?php echo mysql_result($result, $i, 'first_name');?></td>
                            <td><?php echo mysql_result($result, $i, 'last_name');?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>
                            <td><?php 
							$cot=mysql_result($result, $i, 'country');
							  $result44 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");
while ($row44 = mysql_fetch_array($result44)) 
{
	echo  $countryname = $row44['name']; 
}	
?></td>
                            <td><?php 
							$st=mysql_result($result, $i, 'state');
							  $result444 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");
while ($row444 = mysql_fetch_array($result444)) 
{
	echo  $statename = $row444['name']; 
}	
?></td>
                            <td><?php 
							$ct=mysql_result($result, $i, 'city');
							  $result4444 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");
while ($row4444 = mysql_fetch_array($result4444)) 
{
	echo  $cityname = $row4444['name']; 
}	
?></td>
                            <td><?php   //echo "select COUNT(user_id) from mp_drawings where user_id='$id'";
 $result2 = mysql_query("select COUNT(user_id) from mp_drawings where user_id='$id'"); 
				$row2 = mysql_fetch_array($result2);
 echo $total2 = $row2[0];
 ?></td>
                            <td><?php   //echo "select COUNT(user_id) from mp_payments where user_id='$id'";
 $result21 = mysql_query("select COUNT(user_id) from mp_payments where user_id='$id'"); 
				$row21 = mysql_fetch_array($result21);
 echo $total21 = $row21[0];
 ?></td>
                            <td><?php   //echo "select COUNT(amount) from mp_payments where user_id='$id'";
 $result23 = mysql_query("select COUNT(amount) from mp_payments where user_id='$id'"); 
				$row23 = mysql_fetch_array($result23);
 echo $total23 = $row23[0];
 ?></td>
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";	
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- From TO query ENTRANT END ---> 
                    <!--- From TO query DRAWING START --->
                    <?php
					 $dob=$_GET['fromdate'];
				   $todate=$_GET['todate'];						
                     if ($dayfrto3 == 'frtodt')
{	
//$dob = mysql_real_escape_string($_POST['dob']);
//$todate = mysql_real_escape_string($_POST['todate']);
//save data
error_reporting(0);
 //$query1="insert into user(user_email_id,user_status,user_type,user_password,created_date_time,last_updated_date_time,last_login_date_time,user_reset_pwd_status) values('$user_email_id','$user_status','$user_type','$user_password','$created_date_time','$last_updated_date_time','$last_login_date_time','$user_reset_pwd_status')";  
 $php_timestamp = time();
 //echo "SELECT * FROM mp_drawings WHERE date(created_at) >= '$dob' AND (created_at) <= '$todate' AND status='1'";
                  ?>
                    <div class="col-md-12">
                        <h1 class="page-header"> Drawings Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
 $sql="SELECT * FROM mp_drawings WHERE date(created_at) >= '$dob' AND (created_at) <= '$todate' AND status='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Id</th>
                            <th>User Name</th>
                            <th>Theme Name</th>
                            <th>Title</th>
                            <th>Description</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th>Create Date</th>
                            <!--<th>Update Date</th>-->
                            <th>Likes</th>
                            <th>Reports</th>
                            <th>Clicks</th>
                            <th>Volunteer Id</th>
                            <th>Sponsor Amount</th>
                            <th>Sponsor Name</th>
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                             <tr>
                            <td><?php echo mysql_result($result, $i, 'id');?></td>
                            <td><?php  mysql_result($result, $i, 'user_id');
                            $ui=mysql_result($result, $i, 'user_id');
							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");
while ($row77 = mysql_fetch_array($result77)) 
{
	echo $username = $row77['first_name']; 
}	
?></td>
                            <td><?php mysql_result($result, $i, 'id');
                              $ti=mysql_result($result, $i, 'id');
							  $result88 = mysql_query("SELECT * FROM mp_themes WHERE id ='$ti'");
while ($row88 = mysql_fetch_array($result88)) 
{
	echo $themename = $row88['name']; 
}	
?></td>
                            <td><?php echo mysql_result($result, $i, 'title');?></td>
                            <td><?php echo mysql_result($result, $i, 'description');?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'updated_at');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'likes');?></td>
                            <td><?php echo mysql_result($result, $i, 'reports');?></td>
                            <td><?php echo mysql_result($result, $i, 'clicks');?></td>
                            <td><?php echo mysql_result($result, $i, 'volunteer_id');?></td>
                            <td><?php mysql_result($result, $i, 'id');
                              $di=mysql_result($result, $i, 'id');
							  $result98 = mysql_query("SELECT * FROM mp_payments WHERE drawing_id ='$di'");
while ($row98 = mysql_fetch_array($result98)) 
{
	echo $sponsoramount = $row98['amount']; 
	$regionid= $row98['region_id'];
}	
?></td>
<td><?php //mysql_result($result, $i, 'id');
                              //$ti=mysql_result($result, $i, 'id');
							  $result97 = mysql_query("SELECT * FROM mp_themes WHERE region_id ='$regionid'");
while ($row97 = mysql_fetch_array($result97)) 
{
	echo $sponsorname = $row97['title']; 
}	
?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <!--<div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">
    <li class="paginate_button previous" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"><a href="#">Previous</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">1</a></li><li class="paginate_button active" aria-controls="dataTables-example" tabindex="0"><a href="#">2</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">3</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">4</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">5</a></li>
    <li class="paginate_button " aria-controls="dataTables-example" tabindex="0"><a href="#">6</a></li>
    <li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"><a href="#">Next</a></li></ul></div></div>-->
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "entrantsreport.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";	
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- From TO query DRAWING END ---> 
                    <!--- From TO query VOLUNTEER START --->
                    <?php
					 $dob=$_GET['fromdate'];
				   $todate=$_GET['todate'];						
                     if ($dayfrto4 == 'frtovolun')
{	
//$dob = mysql_real_escape_string($_POST['dob']);
//$todate = mysql_real_escape_string($_POST['todate']);
//save data
error_reporting(0);
 //$query1="insert into user(user_email_id,user_status,user_type,user_password,created_date_time,last_updated_date_time,last_login_date_time,user_reset_pwd_status) values('$user_email_id','$user_status','$user_type','$user_password','$created_date_time','$last_updated_date_time','$last_login_date_time','$user_reset_pwd_status')";  
 $php_timestamp = time();
 //echo "SELECT * FROM mp_volunteers WHERE date(created_at) >= '$dob' AND (created_at) <= '$todate' AND status='1'";
                  ?>
                    <div class="col-md-12">
                        <h1 class="page-header">Volunteer Report </h1>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                        <?php
$per_page =30;  // number of results to show per page
 $sql="SELECT * FROM mp_volunteers WHERE date(created_at) >= '$dob' AND (created_at) <= '$todate' AND status='1'";
$result = mysql_query($sql);
//$result = mysql_query("SELECT * FROM events where aduser_id='$aduser_id'");
$total_results = mysql_num_rows($result);
$total_pages = ceil($total_results / $per_page);//total pages we going to have
if($total_results>0)
{
	?>
                        <thead>
                            <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>E Mail Id</th>
                            <!--<th>Address</th>-->
                            <th>Phone</th>
                            <!-- <th>DOB</th>
                              <th>Activities Time</th>--> 
                            <!--<th>Activities Place</th>-->
                            <th>Create Date</th>
                            <th >Volunteer Country</th>
                            <th >Volunteer State</th>
                            <th>Volunteer City</th>
                            <th>No of Entrants Introduced</th>
                            <!--<th>Update Date</th>-->
                            <!--<th>Status</th>-->
                            <!--<th>User Password</th>
                              <th>Created Date Time</th>--> 
                            <!--<th>Edit</th>--> 
                            <!--<th>Delete</th>--> 
                          </tr>
                          </thead>
                        <tbody>
                            <?php
//-------------if page is setcheck------------------//
if (isset($_GET['page']))
 {	 
     $show_page = $_GET['page'];   
	//$show_page = isset( $_GET['page'] )? $_GET['page']: '';          //it will telles the current page
    if ($show_page > 0 && $show_page <= $total_pages) {
        $start = ($show_page - 1) * $per_page;
        $end = $start + $per_page;
    } else {
        // error - show first set of results
        $start = 0;              
        $end = $per_page;
    }
} else {
    // if page isn't set, show first set of results
    $start = 0;
    $end = $per_page;
}
// display pagination
$page = isset($_GET['page']);  
$tpages=$total_pages;
if ($page <= 0)
    $page = 1; 
	//$query=mysql_query("select * from users");
	for ($i = $start; $i < $end; $i++)  
	{
		if ($i == $total_results)
		 {
		 break;
		 }
	?>
                           <tr>
                            <td><?php echo mysql_result($result, $i, 'id');?></td>
                            <td><?php echo  mysql_result($result, $i, 'name');
                            //$ui=mysql_result($result, $i, 'user_id');
//							  $result77 = mysql_query("SELECT * FROM mp_users WHERE id ='$ui'");
//while ($row77 = mysql_fetch_array($result77)) 
//{
//	 $username = $row77['first_name']; 
//}	
?></td>
                            <td><?php echo mysql_result($result, $i, 'email'); ?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'address');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'phone');?></td>
                            <!-- <td><?php //echo mysql_result($result, $i, 'dob');?></td>-->
                            <td><?php echo mysql_result($result, $i, 'created_at');?></td>
                             <td><?php 
							$cot=mysql_result($result, $i, 'country');
							  $result99 = mysql_query("SELECT * FROM mp_countries WHERE id ='$cot'");
while ($row99 = mysql_fetch_array($result99)) 
{
	echo  $countryname = $row99['name']; 
}	
?></td>
                            <td><?php 
							$st=mysql_result($result, $i, 'state');
							  $result999 = mysql_query("SELECT * FROM mp_states WHERE id ='$st'");
while ($row999 = mysql_fetch_array($result999)) 
{
	echo  $statename = $row999['name']; 
}	
?></td>
                            <td><?php 
							$ct=mysql_result($result, $i, 'city');
							  $result9999 = mysql_query("SELECT * FROM mp_cities WHERE id ='$ct'");
while ($row9999 = mysql_fetch_array($result9999)) 
{
	echo  $cityname = $row9999['name']; 
}	
?></td>
<td><?php $entco=mysql_result($result, $i, 'id');
//echo "SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'";
$result9988 = mysql_query("SELECT Count(volunteer_id) FROM mp_drawings WHERE volunteer_id ='$entco'");
				$row9988 = mysql_fetch_array($result9988);
  echo $total9988 = $row9988[0];
?></td>
                            <!--<td><?php //echo mysql_result($result, $i, 'updated_at');?></td>-->
                            <!--<td><?php //echo mysql_result($result, $i, 'status');?></td>-->
                            <!--<td><?php //echo mysql_result($result, $i, 'created_date_time');?></td>--> 
                            <!--<td><?php //echo mysql_result($result, $i, 'useradrole');?></td>--> 
                            <!--<td><img src="events/<?php //echo mysql_result($result, $i, 'eventimage');?>" width="40px" /></td>--> 
                            <!-- <td><a href="edituser.php?id=<?php //echo mysql_result($result, $i, 'id');?>&type=volunteers">Edit</a></td>--> 
                            <!-- <td><a href="deleteevents.php?id=<?php //echo mysql_result($result, $i, 'id');?>&image=<?php //echo mysql_result($result, $i, 'eventimage');?>">Delete</a></td>--> 
                            <!--<td><a href="edit.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Edit</a></td>
		<td><a href="delete.php?email=<?php //echo mysql_result($result, $i, 'telemail');?>">Delete</a></td>--> 
                          </tr>
                            <?php }  ?>
                            <tr>
                            <td colspan="12" align="right"><?php 
	 $reload = "report.php" . "?tpages=" . $tpages;
                    echo '<div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate">
    <ul class="pagination">';
                    if ($total_pages > 1) {
						error_reporting(0);
                        echo paginate($reload, $show_page, $total_pages);
                    } 
                    echo " </ul>
    </div>";
	?>
                                <?php
}
else
{
echo "No records found";	
}
?></td>
                          </tr>
                          </tbody>
                      </table>
                      </div>
                    <?php } ?>
                    <!--- From TO query VOLUNTEER END ---> 
                    <!--- From TO END ---> 
                  </div>
                    <!-- /.col-lg-6 (nested) --> 
                    <!-- /.col-lg-6 (nested) --> 
                  </div>
                <!-- /.row (nested) --> 
              </div>
                <!-- /.panel-body --> 
              </div>
            <!-- /.panel --> 
          </div>
            <!-- /.col-lg-12 --> 
          </div>
        <footer>
            <p>All Right Reserved. Developed By: <a href="#"> Way2winsoftware.com</a></p>
          </footer>
      </div>
        <!-- /. PAGE INNER  --> 
      </div>
    <!-- /. PAGE WRAPPER  --> 
  </div>
  </div>
<!-- /. WRAPPER  --> 
<!-- JS Scripts--> 
<!-- jQuery Js --> 
<!--<script src="assets/js/jquery-1.10.2.js"></script>--> 
<!-- Bootstrap Js --> 
<script src="assets/js/bootstrap.min.js"></script> 
<!-- Metis Menu Js --> 
<script src="assets/js/jquery.metisMenu.js"></script> 
<!-- Custom Js --> 
<script src="assets/js/custom-scripts.js"></script>
</body>
</html>
