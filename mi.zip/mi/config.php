<?php
$con=mysql_connect('localhost','mdd','root123');

$db=mysql_select_db('mdd_db',$con);
?>
