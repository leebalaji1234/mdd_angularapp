﻿<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta charset="utf-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<title>Million Dollar Drawings</title>

<!-- Bootstrap Styles-->

<link href="assets/css/bootstrap.css" rel="stylesheet" />

<!-- FontAwesome Styles-->

<link href="assets/css/font-awesome.css" rel="stylesheet" />

<!-- Morris Chart Styles-->

<link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />

<!-- Custom Styles-->

<link href="assets/css/custom-styles.css" rel="stylesheet" />

<!-- Google Fonts-->

<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>

<body>

<div id="wrapper">

<!--/. NAV TOP  -->

<?php include('menudash.php'); ?>

<!-- /. NAV SIDE  -->

<div id="page-wrapper">

<div id="page-inner">

<div class="row">

  <div class="col-md-12">

    <h1 class="page-header"> Welcome To Million Dollar Drawings <!--<small>Summary of your App</small>--> 

    </h1>

  </div>

</div>

<!-- /. ROW  -->

<?php

error_reporting(0);

?>

<div class="row"> 

  <!--- Today  START --->

  <div class="col-lg-1">

    <form method="post" action="" enctype="multipart/form-data">

      <button class="btn btn-default" name="today">Today</button>

    </form>

  </div>

  <!--- Today  END ---> 

  <!--- ONE Week  START --->

  <div class="col-lg-1">

    <form method="post" action="" enctype="multipart/form-data">
      <?php
//$date = strtotime("+1 week"); 
//date('M d, Y', $date);
?>
      <button class="btn btn-default" name="oneweek">1Week</button>
    </form>
  </div>

  <!--- One WEEk  END ---> 

  <!--- ONE MONTH  START --->

  <div class="col-lg-1">

    <form method="post" action="" enctype="multipart/form-data">

      <button class="btn btn-default" name="onemonth">1 Month</button>

    </form>

  </div>

  <!--- ONE MONTH  END ---> 

  <!--- From TO START --->

  <div class="col-lg-4">

    <form method="post" action="" enctype="multipart/form-data">

      <div class="form-group" style="margin-top:-25px !important;">

     

        <label class="control-label" for="inputSuccess">From Date</label>

         <?php

       if (!empty($_POST['submit']))

{	

 $dob = mysql_real_escape_string($_POST['dob']);

 $todate = mysql_real_escape_string($_POST['todate']);

}

?>

      

        <input type="text" class="form-control" placeholder="Select From Date" name="dob" id="example1" value="<?php echo $dob; ?>"    required>

        <!--<input  type="text" class="form-control" placeholder="click to show datepicker"  name="fromdate" id="example1">--> 

        <script src="assets/js/jquery-1.9.1.min.js"></script> 

        <script src="assets/js/bootstrap-datepicker.js"></script> 

        <script type="text/javascript">

            // When the document is ready

            $(document).ready(function () {                

                $('#example1').datepicker({

                    format: "yyyy-mm-dd"

                });              

            });

        </script> 

      </div>

      <style>

					  .form-control {

    background-color: #fff;

    background-image: none;

    border: 1px solid #ccc;

    border-radius: 4px;

    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;

    color: #555;

    display: block;

    font-size: 14px;

    height: 34px;

    line-height: 1.42857;

    padding: 6px 12px;

    transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;

    width: 50% !important;

}

					  </style>

      <div class="form-group" style="margin-top:-76px !important; margin-left:190px !important; width:100% !important;">

        <label class="control-label" for="inputSuccess">To Date</label>

        <input  type="text" class="form-control" placeholder="Select To Date"  name="todate" value="<?php echo $todate; ?>" id="example2">

        <script src="assets/js/jquery-1.9.1.min.js"></script> 

        <script src="assets/js/bootstrap-datepicker.js"></script> 

        <script type="text/javascript">

            // When the document is ready

            $(document).ready(function () {                

                $('#example2').datepicker({

					 format: "yyyy-mm-dd"

                    //format: "dd/mm/yyyy"

                }); 

            });

        </script> 

      </div>

      <button class="btn btn-default" type="submit" value="submit" name="submit" style="margin-top:-84px !important; margin-left:363px !important;">Submit</button>

    </form>

  </div>

</div>

<div class="row">



<!--- From TO END ---> 

<!--- Today query  START --->

<?php					

					

					if(isset($_POST['today']))

					{

						 $date_today = date('Y-m-d');

					}

					 $onewe=isset($_POST['oneweek']);

					$onemo=isset($_POST['onemonth']);

					$frtom=isset($_POST['submit']);	

				   if($date_today =='' && $onewe=='' && $frtom=='' && $onemo=='' )

					{

     $date_today = date('Y-m-d');		  ?>

<!--- Today start Sponsor -->

      <?php

	  $result1 = mysql_query("select COUNT(id) from mp_regions where date(created_on)='$date_today' AND status='1'"); 

				$row1 = mysql_fetch_array($result1);

  $total1 = $row1[0]; 

	  $result1234 = mysql_query("select COUNT(x) from mp_regions where date(created_on)='$date_today' AND status='1'"); 

				$row1234 = mysql_fetch_array($result1234);

  $total1234 = $row1234[0];   				

    

  $result12 = mysql_query("select COUNT(c.id) from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on='$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status = '1' AND  d.type='2'"); 

				$row12 = mysql_fetch_array($result12);				

  $total12 = $row12[0];  

  $result123 = mysql_query("select COUNT(c.id) from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on='$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status = '1' AND  d.type='1'"); 

				$row123 = mysql_fetch_array($result123);				

  $total123 = $row123[0]; 

    $result11 = mysql_query("SELECT COUNT(id) FROM mp_regions where status='0' AND date(created_on)='$date_today' AND status = '0'"); 

				$row11 = mysql_fetch_array($result11);

   $total11 = $row11[0];

?>

<div class="col-md-3 col-sm-12 col-xs-12">

                        <div class="panel panel-primary text-center no-boder bg-color-green">

                            <div class="panel-body">

                               <a href="report.php?date=<?php echo $date_today; ?>&tspo=tspo"><h5>Total Signed up: <?php  echo  $total1; ?></h5></a>

                               <a href="report.php?date=<?php echo $date_today; ?>&regth=regth"><h5>Total Pixels purchased: 0 <?php  //echo   $total1234; ?></h5></a>

                                 <a href="report.php?date=<?php echo $date_today; ?>&trt=trt"><h5>Regular Themes: <?php  echo  $total12; ?></h5></a>

                                  <a href="report.php?date=<?php echo $date_today; ?>&tst=tst"><h5>Special Themes: <?php  echo  $total123; ?></h5></a>                                  <a href="report1.php?date=<?php echo $date_today; ?>&tspo=tspo"> <h5>Blocked: <?php echo  $total11; ?></h5></a>

                            </div>

                            <div class="panel-footer back-footer-green">

                                Sponsors

                            </div>

                        </div>

                    </div>        

                    <!--- Today END Sponsor -->                   

	  <!--- Today start Entrant -->

      <?php	

	  $result2 = mysql_query("select COUNT(id) from mp_users where date(created_at)='$date_today' AND is_confirmed = '1'"); 

				$row2 = mysql_fetch_array($result2);

  $total2 = $row2[0];

    $result22 = mysql_query("SELECT COUNT(id) FROM mp_users where is_confirmed='0' AND date(created_at)='$date_today'"); 

				$row22 = mysql_fetch_array($result22);

   $total22 = $row22[0];	

?>

<div class="col-md-3 col-sm-12 col-xs-12">                      

                        <div class="panel panel-primary text-center no-boder bg-color-blue">

                            <div class="panel-body">

                                <!--<i class="fa fa-shopping-cart fa-5x"></i>-->                                

                               <?php //$date_today = date('Y-m-d');  ?>

                                <a href="report.php?date=<?php echo $date_today; ?>&ent=ent"><h5>Total Signed Up: <?php  echo  $total2; ?></h5></a>

                                <a href="report1.php?date=<?php echo $date_today; ?>&ent=ent"> <h5>Blocked:<?php echo  $total22; ?> </h5></a>

                                <br /><br />

                                <!--<a href="entrantsreport.php" class="btn btn-info">Detail Reports</a>--><br /><br />

                            </div>

                            <div class="panel-footer back-footer-blue">

                                Entrants

                            </div>

                        </div>

                    </div>

	  <!--- Today end Entrant -->      

	  <!--- Today start Drawings -->

      <?php	

	 $result3 = mysql_query("select COUNT(id) from mp_drawings where date(created_at)='$date_today' AND status = '0'"); 

				$row3 = mysql_fetch_array($result3);

  $total3 = $row3[0];

  $result33 = mysql_query("SELECT COUNT(id) FROM mp_drawings where status='1' AND date(created_at)='$date_today'"); 

				$row33 = mysql_fetch_array($result33);

   $total33 = $row33[0];

?>

 <div class="col-md-3 col-sm-12 col-xs-12">                                                    

                        <div class="panel panel-primary text-center no-boder bg-color-red">

                            <div class="panel-body">

                                <a href="report.php?date=<?php echo $date_today; ?>&tdt=tdt"><h5>Total Drawings: <?php echo  $total3; ?> </h5> </a>

                                <a href="report1.php?date=<?php echo $date_today; ?>&tdt=tdt"><h5>Blocked: <?php echo $total33; ?></h5></a>                                <br /><br /><br /><br />

                            </div>

                            <div class="panel-footer back-footer-red">

                                 Drawings

                            </div>

                        </div>

                    </div>                    

	  <!--- Today End Drawings -->

	  <!--- Today start Volunteer -->

      <?php	 

	 $result4 = mysql_query("select COUNT(id) from mp_volunteers where date(created_at)='$date_today' AND status='1'"); 

				$row4 = mysql_fetch_array($result4);

  $total4 = $row4[0];	 

  $result44 = mysql_query("SELECT COUNT(id) FROM mp_volunteers where status='0' AND date(created_at)='$date_today'"); 

				$row44 = mysql_fetch_array($result44);

   $total44 = $row44[0];	  

	 ?>     

       <div class="col-md-3 col-sm-12 col-xs-12">                    

                        <div class="panel panel-primary text-center no-boder bg-color-brown">

                            <div class="panel-body">

                             <a href="report.php?date=<?php echo $date_today; ?>&tvolun=tvolun"> <h5>Total Signed up: <?php echo  $total4; ?></h5></a>

                             <a href="report1.php?date=<?php echo $date_today; ?>&tvolun=tvolun"> <h5>Blocked: <?php echo  $total44; ?></h5></a>

                                <br /><br /><br /><br />

                            </div>

                            <div class="panel-footer back-footer-brown">

                               Volunteers

                            </div>

                        </div>

                    </div>

                </div>     

	  <!--- Today End Volunteer -->

                    <?php } ?>

                    <!--- Today query  END ---> 

                     <!--- Today query  START --->

                    <?php

                     if(isset($_POST['today']))

{

     $date_today = date('Y-m-d');		  ?>

	  <!--- Today start Sponsor -->

      <?php

	  $result1 = mysql_query("select COUNT(id) from mp_regions where date(created_on)='$date_today' AND status='1'"); 

				$row1 = mysql_fetch_array($result1);

  $total1 = $row1[0];  

  

	  $result1234 = mysql_query("select COUNT(x) from mp_regions where date(created_on)='$date_today' AND status='1'"); 

				$row1234 = mysql_fetch_array($result1234);

  $total1234 = $row1234[0];   

$result12 = mysql_query("select COUNT(c.id) from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on='$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status = '1' AND  d.type='2'"); 

				$row12 = mysql_fetch_array($result12);				

  $total12 = $row12[0];  

  $result123 = mysql_query("select COUNT(c.id) from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on='$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status = '1' AND  d.type='1'"); 

				$row123 = mysql_fetch_array($result123);				

  $total123 = $row123[0]; 

    $result11 = mysql_query("SELECT COUNT(id) FROM mp_regions where status='0' AND date(created_on)='$date_today'"); 

				$row11 = mysql_fetch_array($result11);

   $total11 = $row11[0];

?>

<div class="col-md-3 col-sm-12 col-xs-12">

                        <div class="panel panel-primary text-center no-boder bg-color-green">

                            <div class="panel-body">

                               <a href="report.php?date=<?php echo $date_today; ?>&tspo=tspo"><h5>Total Signed up: <?php  echo  $total1; ?></h5></a>

                               <a href="#"><h5>Total Pixels purchased: 0 <?php // echo   $total1234; ?></h5></a>

                                 <a href="report.php?date=<?php echo $date_today; ?>&trt=trt"><h5>Regular Themes: <?php  echo  $total12; ?></h5></a>

                                  <a href="report.php?date=<?php echo $date_today; ?>&tst=tst"><h5>Special Themes: <?php  echo  $total123; ?></h5></a>

                                  <a href="report1.php?date=<?php echo $date_today; ?>&tspo=tspo"> <h5>Blocked: <?php echo  $total11; ?></h5></a>                            </div>

                            <div class="panel-footer back-footer-green">

                                Sponsors

                            </div>

                        </div>

                    </div>        

                    <!--- Today END Sponsor -->

	  <!--- Today start Entrant -->

      <?php	

	  $result2 = mysql_query("select COUNT(id) from mp_users where date(created_at)='$date_today' AND is_confirmed = '1'"); 

				$row2 = mysql_fetch_array($result2);

  $total2 = $row2[0];

    $result22 = mysql_query("SELECT COUNT(id) FROM mp_users where is_confirmed='0' AND date(created_at)='$date_today'"); 

				$row22 = mysql_fetch_array($result22);

   $total22 = $row22[0];	

?>

<div class="col-md-3 col-sm-12 col-xs-12">

                        <div class="panel panel-primary text-center no-boder bg-color-blue">

                            <div class="panel-body">                            

                               <?php //$date_today = date('Y-m-d');  ?>

                                <a href="report.php?date=<?php echo $date_today; ?>&ent=ent"><h5>Total Signed Up: <?php  echo  $total2; ?></h5></a>

                                <a href="report1.php?date=<?php echo $date_today; ?>&ent=ent"> <h5>Blocked:<?php echo  $total22; ?> </h5></a>

                                <br /><br /><br /><br />

                            </div>

                            <div class="panel-footer back-footer-blue">

                                Entrants

                            </div>

                        </div>

                    </div>

	  <!--- Today end Entrant -->      

	  <!--- Today start Drawings -->

      <?php	 

	 $result3 = mysql_query("select COUNT(id) from mp_drawings where date(created_at)='$date_today' AND status='0'"); 

				$row3 = mysql_fetch_array($result3);

  $total3 = $row3[0];

  $result33 = mysql_query("SELECT COUNT(id) FROM mp_drawings where status='1' AND date(created_at)='$date_today'"); 

				$row33 = mysql_fetch_array($result33);

   $total33 = $row33[0];

?>

 <div class="col-md-3 col-sm-12 col-xs-12">                                                    

                        <div class="panel panel-primary text-center no-boder bg-color-red">

                            <div class="panel-body">

                                <a href="report.php?date=<?php echo $date_today; ?>&tdt=tdt"><h5>Total Drawings: <?php echo  $total3; ?> </h5> </a>

                                <a href="report1.php?date=<?php echo $date_today; ?>&tdt=tdt"><h5>Blocked: <?php echo $total33; ?></h5></a>                                <br /><br /><br /><br />

                            </div>

                            <div class="panel-footer back-footer-red">

                                 Drawings

                            </div>

                        </div>

                    </div>                    

	  <!--- Today End Drawings -->

	  <!--- Today start Volunteer -->

      <?php	 

	 $result4 = mysql_query("select COUNT(id) from mp_volunteers where date(created_at)='$date_today' AND status='1'"); 

				$row4 = mysql_fetch_array($result4);

  $total4 = $row4[0];	 

  $result44 = mysql_query("SELECT COUNT(id) FROM mp_volunteers where status='0' AND date(created_at)='$date_today'"); 

				$row44 = mysql_fetch_array($result44);

   $total44 = $row44[0];	  

	 ?>     

       <div class="col-md-3 col-sm-12 col-xs-12">                    

                        <div class="panel panel-primary text-center no-boder bg-color-brown">

                            <div class="panel-body">

                             <a href="report.php?date=<?php echo $date_today; ?>&tvolun=tvolun"> <h5>Total Signed up: <?php echo  $total4; ?></h5></a>

                             <a href="report1.php?date=<?php echo $date_today; ?>&tvolun=tvolun"> <h5>Blocked: <?php echo  $total44; ?></h5></a>

                                <br /><br /><br /><br />

                            </div>

                            <div class="panel-footer back-footer-brown">

                               Volunteers

                            </div>

                        </div>

                    </div>

                </div>     

	  <!--- Today End Volunteer -->

                    <?php } ?>

                    <!--- Today query  END --->                     

                     <!--- ONe WEEk  query START --->

                    <?php

                     if(isset($_POST['oneweek']))

{

     $date_today = date('Y-m-d');

	  $date_oneweek = strtotime("-1 week"); 

  $date_oneweek = date('Y-m-d', $date_oneweek);	

	 ?>

       <!--- ONe WEEk start Sponsor -->

      <?php


$result1 = mysql_query("select COUNT(id) from mp_regions where date(created_on) >= '$date_oneweek' AND date(created_on) <= '$date_today' AND status='1'"); 

				$row1 = mysql_fetch_array($result1);

  $total1 = $row1[0]; 

	  $result1234 = mysql_query("select COUNT(x) from mp_regions where date(created_on) >= '$date_oneweek' AND date(created_on) <= '$date_today' AND status='1'"); 

				$row1234 = mysql_fetch_array($result1234);

  $total1234 = $row1234[0]; 		

    

  $result12 = mysql_query("select COUNT(c.id) from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$date_oneweek' AND a.created_on <= '$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='2'");    

				$row12 = mysql_fetch_array($result12);				

  $total12 = $row12[0];  			    

  $result123 = mysql_query("select COUNT(c.id) from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$date_oneweek' AND a.created_on <= '$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='1'");  

				$row123 = mysql_fetch_array($result123);				

  $total123 = $row123[0]; 

   $result11 = mysql_query("SELECT COUNT(id) FROM mp_regions where status='0' AND  date(created_on) >= '$date_oneweek' AND date(created_on) <= '$date_today'");

				$row11 = mysql_fetch_array($result11);

   $total11 = $row11[0];

?>

<div class="col-md-3 col-sm-12 col-xs-12">

                        <div class="panel panel-primary text-center no-boder bg-color-green">

                            <div class="panel-body">

                              <a href="report.php?date1=<?php echo $date_oneweek; ?>&date2=<?php echo $date_today; ?>&owspo=owspo"><h5>Total Signed up: <?php  echo  $total1; ?></h5></a>   

                               <a href="#"><h5>Total Pixels purchased: 0 <?php  //echo   $total1234; ?></h5></a>

                                 <a href="report.php?date1=<?php echo $date_oneweek; ?>&date2=<?php echo $date_today; ?>&owrt=owrt"><h5>Regular Themes: <?php  echo  $total12; ?></h5></a>

                                  <a href="report.php?date1=<?php echo $date_oneweek; ?>&date2=<?php echo $date_today; ?>&owst=owst"><h5>Special Themes: <?php  echo  $total123; ?></h5></a>

                               <a href="report1.php?date1=<?php echo $date_oneweek; ?>&date2=<?php echo $date_today; ?>&owspo=owspo"><h5>Blocked: <?php echo  $total11; ?></h5></a> 

                            </div>

                            <div class="panel-footer back-footer-green">

                                Sponsors

                            </div>

                        </div>

                    </div>        

                    <!--- ONe WEEk END Sponsor -->

     <!--- one week start Entrant -->

      <?php	  

//echo "SELECT COUNT(id) FROM mp_users WHERE date(created_at) >= '$date_oneweek' AND date(created_at) <= '$date_today' AND is_confirmed='1'";

//echo "SELECT COUNT(id) FROM mp_users WHERE (created_at BETWEEN  '$date_oneweek' AND  '$date_today') AND is_confirmed='1'";

$result2 = mysql_query("SELECT COUNT(id) FROM mp_users WHERE date(created_at) >= '$date_oneweek' AND date(created_at) <= '$date_today' AND is_confirmed='1'"); 				$row2 = mysql_fetch_array($result2);

  $total2 = $row2[0];

$result22 = mysql_query("SELECT COUNT(id) FROM mp_users where is_confirmed='0' AND date(created_at) >= '$date_oneweek' AND date(created_at) <= '$date_today'"); 

				$row22 = mysql_fetch_array($result22);

   $total22 = $row22[0];	

?>

 <div class="col-md-3 col-sm-12 col-xs-12">                      

                        <div class="panel panel-primary text-center no-boder bg-color-blue">

                            <div class="panel-body">

                             <a href="report.php?date1=<?php echo $date_oneweek; ?>&date2=<?php echo $date_today; ?>&owent=owent"><h5>Total Signed Up: <?php  echo  $total2; ?></h5></a>

                             <a href="report1.php?date1=<?php echo $date_oneweek; ?>&date2=<?php echo $date_today; ?>&owent=owent"><h5>Blocked:<?php echo  $total22; ?> </h5></a>

                                <br /><br /><br /><br />

                            </div>

                            <div class="panel-footer back-footer-blue">

                                Entrants

                            </div>

                        </div>

                    </div>

	  <!--- one week end Entrant -->   

      <!--- one week start Drawings -->

      <?php		 

	 $result3 = mysql_query("select COUNT(id) FROM mp_drawings WHERE date(created_at) >= '$date_oneweek' AND date(created_at) <= '$date_today' AND status='0'"); 

				$row3 = mysql_fetch_array($result3);

  $total3 = $row3[0];

 $result33 = mysql_query("SELECT COUNT(id) FROM mp_drawings where status='1' AND  date(created_at) >= '$date_oneweek' AND date(created_at) <= '$date_today'");

				$row33 = mysql_fetch_array($result33);

   $total33 = $row33[0];

?>

 <div class="col-md-3 col-sm-12 col-xs-12">                                                   

                        <div class="panel panel-primary text-center no-boder bg-color-red">

                            <div class="panel-body">

                                <a href="report.php?date1=<?php echo $date_oneweek; ?>&date2=<?php echo $date_today; ?>&owdt=owdt"><h5>Total Drawings: <?php echo  $total3; ?> </h5></a>

                                <a href="report1.php?date1=<?php echo $date_oneweek; ?>&date2=<?php echo $date_today; ?>&owdt=owdt"><h5>Blocked: <?php echo $total33; ?></h5></a>

                                <br /><br /><br /><br />

                            </div>

                            <div class="panel-footer back-footer-red">

                                 Drawings

                            </div>

                        </div>

                    </div>

	  <!--- one week End Drawings -->

	  <!--- one week start Volunteer -->

      <?php	 

	 $result4 = mysql_query("select COUNT(id) FROM mp_volunteers WHERE date(created_at) >= '$date_oneweek' AND date(created_at) <= '$date_today' AND status='1'"); 

				$row4 = mysql_fetch_array($result4);

  $total4 = $row4[0];	

  $result44 = mysql_query("SELECT COUNT(id) FROM mp_volunteers where status='0' AND  date(created_at) >= '$date_oneweek' AND date(created_at) <= '$date_today'"); 

				$row44 = mysql_fetch_array($result44);

   $total44 = $row44[0];	 

	 ?>     

       <div class="col-md-3 col-sm-12 col-xs-12">                    

                        <div class="panel panel-primary text-center no-boder bg-color-brown">

                            <div class="panel-body">

                                <a href="report.php?date1=<?php echo $date_oneweek; ?>&date2=<?php echo $date_today; ?>&owvolun=owvolun"> <h5>Total Signed up: <?php echo  $total4; ?></h5></a> 

                                <a href="report1.php?date1=<?php echo $date_oneweek; ?>&date2=<?php echo $date_today; ?>&owvolun=owvolun"><h5>Blocked: <?php echo  $total44; ?></h5></a>    

                                <br /><br /><br /><br />

                            </div>

                            <div class="panel-footer back-footer-brown">

                               Volunteers

                            </div>

                        </div>

                    </div>     

	  <!--- one week End Volunteer -->                    

                    <?php } ?>

                    <!--- One week query  END --->                       

                    <!--- ONE MONTH query  START --->

                    <?php

                     if(isset($_POST['onemonth']))

{

     $date_today = date('Y-m-d');

 $date_onemonth = strtotime("-1 month");

 $date_onemonth = date('Y-m-d', $date_onemonth); 

	 ?>                   

      <!--- one monthstart Sponsor -->

      <?php	  

	  $result1 = mysql_query("SELECT COUNT(id) FROM mp_regions WHERE date(created_on) >= '$date_onemonth' AND date(created_on) <= '$date_today' AND status='1'"); 

				$row1 = mysql_fetch_array($result1);

  $total1 = $row1[0]; 

  

	  $result1234 = mysql_query("select COUNT(x) from mp_regions where date(created_on) >= '$date_onemonth' AND date(created_on) <= '$date_today' AND status='1'"); 

				$row1234 = mysql_fetch_array($result1234);

  $total1234 = $row1234[0]; 

  

  					

    

  $result12 = mysql_query("select COUNT(c.id) from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$date_onemonth' AND a.created_on <= '$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='2'");   

				$row12 = mysql_fetch_array($result12);				

  $total12 = $row12[0];  

  

  $result123 = mysql_query("select COUNT(c.id) from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$date_onemonth' AND a.created_on <= '$date_today' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='1'"); 

				$row123 = mysql_fetch_array($result123);				

  $total123 = $row123[0]; 

   $result11 = mysql_query("SELECT COUNT(id) FROM mp_regions where status='0' AND date(created_on) >= '$date_onemonth' AND date(created_on) <= '$date_today'");

				$row11 = mysql_fetch_array($result11);

   $total11 = $row11[0];

?>

<div class="col-md-3 col-sm-12 col-xs-12">

                        <div class="panel panel-primary text-center no-boder bg-color-green">

                            <div class="panel-body">

                              <a href="report.php?date1m=<?php echo $date_onemonth; ?>&date2m=<?php echo $date_today; ?>&omspo=omspo"><h5>Total Signed up: <?php  echo  $total1; ?></h5></a>    

                               <a href="#"><h5>Total Pixels purchased: 0 <?php  //echo   $total1234; ?></h5></a>

                                 <a href="report.php?date1m=<?php echo $date_onemonth; ?>&date2m=<?php echo $date_today; ?>&omrt=omrt"><h5>Regular Themes: <?php  echo  $total12; ?></h5></a>

                                  <a href="report.php?date1m=<?php echo $date_onemonth; ?>&date2m=<?php echo $date_today; ?>&omst=omst"><h5>Special Themes: <?php  echo  $total123; ?></h5></a>

                                   <a href="report1.php?date1m=<?php echo $date_onemonth; ?>&date2m=<?php echo $date_today; ?>&omspo=omspo"> <h5>Blocked: <?php echo  $total11; ?></h5></a>

                            </div>

                            <div class="panel-footer back-footer-green">

                                Sponsors

                            </div>

                        </div>

                    </div>        

                    <!--- one month END Sponsor -->

     <!--- one month start Entrant -->

      <?php

	  $result2 = mysql_query("SELECT COUNT(id) FROM mp_users WHERE date(created_at) >= '$date_onemonth' AND date(created_at) <= '$date_today' AND is_confirmed='1'"); 

				$row2 = mysql_fetch_array($result2);

  $total2 = $row2[0];

  $result22 = mysql_query("SELECT COUNT(id) FROM mp_users where is_confirmed='0' AND date(created_at) >= '$date_onemonth' AND date(created_at) <= '$date_today'"); 

				$row22 = mysql_fetch_array($result22);

   $total22 = $row11[0];	

?>

 <div class="col-md-3 col-sm-12 col-xs-12">                      

                        <div class="panel panel-primary text-center no-boder bg-color-blue">

                            <div class="panel-body">

                                <a href="report.php?date1m=<?php echo $date_onemonth; ?>&date2m=<?php echo $date_today; ?>&oment=oment"><h5>Total Signed Up: <?php  echo  $total2; ?></h5></a>

                                 <a href="report1.php?date1m=<?php echo $date_onemonth; ?>&date2m=<?php echo $date_today; ?>&oment=oment"><h5>Blocked:<?php echo  $total22; ?> </h5></a>                                

                                <br /><br />

                                <br /><br />

                            </div>

                            <div class="panel-footer back-footer-blue">

                                Entrants

                            </div>

                        </div>

                    </div>

	  <!--- one month end Entrant -->   

      <!--- one month start Drawings -->

      <?php	

	   

	 $result3 = mysql_query("SELECT COUNT(id) FROM mp_drawings WHERE date(created_at) >= '$date_onemonth' AND date(created_at) <= '$date_today' AND status='0'"); 

				$row3 = mysql_fetch_array($result3);

  $total3 = $row3[0];

  

 $result33 = mysql_query("SELECT COUNT(id) FROM mp_drawings where status='1' AND date(created_at) >= '$date_onemonth' AND date(created_at) <= '$date_today'");

				$row33 = mysql_fetch_array($result33);

   $total33 = $row33[0];

?>

 <div class="col-md-3 col-sm-12 col-xs-12">   

                        <div class="panel panel-primary text-center no-boder bg-color-red">

                            <div class="panel-body">

                                <a href="report.php?date1m=<?php echo $date_onemonth; ?>&date2m=<?php echo $date_today; ?>&omdt=omdt"> <h5>Total Drawings: <?php echo  $total3; ?> </h5></a>

                                 <a href="report1.php?date1m=<?php echo $date_onemonth; ?>&date2m=<?php echo $date_today; ?>&omdt=omdt">  <h5>Blocked: <?php echo $total33; ?></h5></a><br /><br />

                                 <br /><br />

                            </div>

                            <div class="panel-footer back-footer-red">

                                 Drawings

                            </div>

                        </div>

                    </div>

	  <!--- one month End Drawings -->

	  <!--- one month start Volunteer -->

      <?php	 

	   

	 $result4 = mysql_query("SELECT COUNT(id) FROM mp_volunteers WHERE date(created_at) >= '$date_onemonth' AND date(created_at) <= '$date_today' AND status='1'"); 

				$row4 = mysql_fetch_array($result4);

  $total4 = $row4[0];	

  

  $result44 = mysql_query("SELECT COUNT(id) FROM mp_volunteers where status='0' AND date(created_at) >= '$date_onemonth' AND date(created_at) <= '$date_today'"); 

				$row44 = mysql_fetch_array($result44);

   $total44 = $row44[0];	 

	 ?>

       <div class="col-md-3 col-sm-12 col-xs-12">                    

                        <div class="panel panel-primary text-center no-boder bg-color-brown">

                            <div class="panel-body">

                                <a href="report.php?date1m=<?php echo $date_onemonth; ?>&date2m=<?php echo $date_today; ?>&omvolun=omvolun"> <h5>Total Signed up: <?php echo  $total4; ?></h5></a>

                                 <a href="report1.php?date1m=<?php echo $date_onemonth; ?>&date2m=<?php echo $date_today; ?>&omvolun=omvolun"><h5>Blocked: <?php echo  $total44; ?></h5></a>

                                <br /><br /><br /><br />

                            </div>

                            <div class="panel-footer back-footer-brown">

                               Volunteers

                            </div>

                        </div>

                    </div>     

	  <!--- one month End Volunteer -->                    

                    <?php } ?>                    

                    <!--- One MONTH query  END --->

                      <!--- From TO query START --->

                    <?php

                     if (!empty($_POST['submit']))

{	

$dob = mysql_real_escape_string($_POST['dob']);

$todate = mysql_real_escape_string($_POST['todate']);

//save data

error_reporting(0);

 $php_timestamp = time();

                  ?>

                     <!--- From to start Sponsor -->

      <?php	  

	  $result1 = mysql_query("SELECT COUNT(id) FROM mp_regions WHERE date(created_on) >= '$dob' AND date(created_on) <= '$todate' AND status='1'"); 

				$row1 = mysql_fetch_array($result1);

  $total1 = $row1[0];    

  

	  $result1234 = mysql_query("select COUNT(x) from mp_regions where date(created_on) >= '$dob' AND date(created_on) <= '$todate' AND status='1'"); 

				$row1234 = mysql_fetch_array($result1234);

  $total1234 = $row1234[0];

  

  		

    

  $result12 = mysql_query("select COUNT(c.id) from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$dob' AND a.created_on <= '$todate' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='2'");   

				$row12 = mysql_fetch_array($result12);				

  $total12 = $row12[0];  

  		    

  $result123 = mysql_query("select COUNT(c.id) from mp_regions AS a ,mp_drawings AS b , mp_themes AS c , mp_theme_categories AS d where a.created_on >= '$dob' AND a.created_on <= '$todate' AND a.user_id = b.user_id AND b.theme_id = c.id AND c.category_id = d.id AND c.status='1' AND  d.type='1'");

				$row123 = mysql_fetch_array($result123);				

  $total123 = $row123[0];

  

    $result11 = mysql_query("SELECT COUNT(id) FROM mp_regions where status='0' AND date(created_on) >= '$dob' AND date(created_on) <= '$todate'"); 

				$row11 = mysql_fetch_array($result11);

   $total11 = $row11[0];

?>

<div class="col-md-3 col-sm-12 col-xs-12">

                        <div class="panel panel-primary text-center no-boder bg-color-green">

                            <div class="panel-body">

                                <a href="report.php?fromdate=<?php echo $dob; ?>&todate=<?php echo $todate; ?>&frtospo=frtospo"><h5>Total Signed up: <?php  echo  $total1; ?></h5></a>  

                               <a href="#"><h5>Total Pixels purchased: 0 <?php // echo   $total1234; ?></h5></a>

                                 <a href="report.php?fromdate=<?php echo $dob; ?>&todate=<?php echo $todate; ?>&frtort=frtort"><h5>Regular Themes: <?php  echo  $total12; ?></h5></a>

                                  <a href="report.php?fromdate=<?php echo $dob; ?>&todate=<?php echo $todate; ?>&frtost=frtost"><h5>Special Themes: <?php  echo  $total123; ?></h5></a>                              

                               <a href="report1.php?fromdate=<?php echo $dob; ?>&todate=<?php echo $todate; ?>&frtospo=frtospo"><h5>Blocked: <?php echo  $total11; ?></h5></a>      

                            </div>

                            <div class="panel-footer back-footer-green">

                                Sponsors

                            </div>

                        </div>

                    </div>        

                    <!--- From to END Sponsor -->                  

     <!--- From to start Entrant -->

      <?php

	  	

	  $result2 = mysql_query("SELECT COUNT(id) FROM mp_users WHERE date(created_at) >= '$dob' AND date(created_at) <= '$todate' AND is_confirmed='1'"); 

				$row2 = mysql_fetch_array($result2);

  $total2 = $row2[0];

  $result22 = mysql_query("SELECT COUNT(id) FROM mp_users where is_confirmed='0' AND date(created_at) >= '$dob' AND date(created_at) <= '$todate'"); 

				$row22 = mysql_fetch_array($result22);

   $total22 = $row22[0];	

?>

 <div class="col-md-3 col-sm-12 col-xs-12">                      

                        <div class="panel panel-primary text-center no-boder bg-color-blue">

                            <div class="panel-body">

                                 <a href="report.php?fromdate=<?php echo $dob; ?>&todate=<?php echo $todate; ?>&frtoent=frtoent"> <h5>Total Signed Up: <?php  echo  $total2; ?></h5></a> 

                                   <a href="report1.php?fromdate=<?php echo $dob; ?>&todate=<?php echo $todate; ?>&frtoent=frtoent"> <h5>Blocked:<?php echo  $total22; ?> </h5></a>    

                                <br /><br /><br /><br />

                            </div>

                            <div class="panel-footer back-footer-blue">

                                Entrants

                            </div>

                        </div>

                    </div>

	  <!--- From to end Entrant -->   

      <!--- From to start Drawings -->

      <?php	

	 $result3 = mysql_query("SELECT COUNT(id) FROM mp_drawings WHERE date(created_at) >= '$dob' AND date(created_at) <= '$todate' AND status='0'"); 

				$row3 = mysql_fetch_array($result3);

  $total3 = $row3[0];

  $result33 = mysql_query("SELECT COUNT(id) FROM mp_drawings where status='1' AND date(created_at) >= '$dob' AND date(created_at) <= '$todate'"); 

				$row33 = mysql_fetch_array($result33);

   $total33 = $row33[0];

?>

 <div class="col-md-3 col-sm-12 col-xs-12">   

                        <div class="panel panel-primary text-center no-boder bg-color-red">

                            <div class="panel-body">

                                <a href="report.php?fromdate=<?php echo $dob; ?>&todate=<?php echo $todate; ?>&frtodt=frtodt">  <h5>Total Drawings: <?php echo  $total3; ?> </h5> </a>  

                                 <a href="report1.php?fromdate=<?php echo $dob; ?>&todate=<?php echo $todate; ?>&frtodt=frtodt">  <h5>Blocked: <?php echo $total33; ?></h5> </a>    <br /><br /><br /><br />

                            </div>

                            <div class="panel-footer back-footer-red">

                                 Drawings

                            </div>

                        </div>

                    </div>

	  <!--- From to End Drawings -->

	  <!--- From to start Volunteer -->

      <?php	 	 

	 $result4 = mysql_query("SELECT COUNT(id) FROM mp_volunteers WHERE date(created_at) >= '$dob' AND date(created_at) <= '$todate' AND status='1'"); 

				$row4 = mysql_fetch_array($result4);

  $total4 = $row4[0];	

  $result44 = mysql_query("SELECT COUNT(id) FROM mp_volunteers where status='0' AND date(created_at) >= '$dob' AND date(created_at) <= '$todate'"); 

				$row44 = mysql_fetch_array($result44);

   $total44 = $row44[0];	 

	 ?>

       <div class="col-md-3 col-sm-12 col-xs-12">                    

                        <div class="panel panel-primary text-center no-boder bg-color-brown">

                            <div class="panel-body">

                                 <a href="report.php?fromdate=<?php echo $dob; ?>&todate=<?php echo $todate; ?>&frtovolun=frtovolun"><h5>Total Signed up: <?php echo  $total4; ?></h5></a>  

                                 <a href="report1.php?fromdate=<?php echo $dob; ?>&todate=<?php echo $todate; ?>&frtovolun=frtovolun"><h5>Blocked: <?php echo  $total44; ?></h5></a>   <br /><br /><br /><br />

                            </div>

                            <div class="panel-footer back-footer-brown">

                               Volunteers

                            </div>

                        </div>

                    </div>     

	  <!--- From to End Volunteer --> 

                    <?php } ?>

                    <!--- From TO END ---> 

                </div>

                

                <!-- /. ROW  -->                

                <!-- /. ROW  -->

				<footer><p>Million Dollar Drawings All right reserved. Developed By: <a href="#"> way2win software</a></p></footer>

            </div>

            <!-- /. PAGE INNER  -->

        </div>

        <!-- /. PAGE WRAPPER  -->

    </div>

    <!-- /. WRAPPER  -->

    <!-- JS Scripts-->

    <!-- jQuery Js -->

   <!-- <script src="assets/js/jquery-1.10.2.js"></script>-->

    <!-- Bootstrap Js -->

    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Metis Menu Js -->

    <script src="assets/js/jquery.metisMenu.js"></script>

    <!-- Morris Chart Js -->

    <script src="assets/js/morris/raphael-2.1.0.min.js"></script>

    <script src="assets/js/morris/morris.js"></script>

    <!-- Custom Js -->

    <script src="assets/js/custom-scripts.js"></script>

</body>

</html>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>